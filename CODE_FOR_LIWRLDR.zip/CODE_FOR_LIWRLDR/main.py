import re
import sys
import warnings
import numpy as np
from pathlib import Path

from sklearnex import patch_sklearn
patch_sklearn()

from load_data_set.process_arff import *
from log.experiment_log_v2 import *
import warnings
warnings.filterwarnings("ignore")


def doDraw(data_set, dataset_nickname, selector_names, selector_names_upper, result_path, metric, metric_nickname):
    markers = ["D", "o", "x", "d", "^", "*", "H", "v", "<", "s", "P", ",",  ".", "1", "2", "3", "4",  "."]
    colors = ["mediumturquoise", "gold", "darkslateblue", "m", "r", "brown",
              "darkgreen", "blue", "gray", "darkgoldenrod", "black", "crimson", "midnightblue", "tan", "limegreen"]
    for i in range(len(metric)):
        drowPicture(data_set, dataset_nickname, selector_names, selector_names_upper, metric[i], metric_nickname[i], markers, colors, result_path)
    print("绘图完成")


def histTable_four_cv(data_set, selector_names, result_paths, result_path, cvs):
    draw_table_four_cv(data_set, selector_names, "zero_one_loss", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "hamming_loss", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "macro_f1", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "micro_f1", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "label_rank_average_precision", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "micro_auc", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "coverage", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "average_precision", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "ranking_loss", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "jaccard_score_macro", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "jaccard_score_micro", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "subSetAccuracy", result_paths, result_path, cvs)
    draw_table_four_cv(data_set, selector_names, "one_error", result_paths, result_path, cvs)
    print("图完成")



def setup():
    # 主程序
    data_set_list_all = ["Arts", "birds", "Business", "Education", "Emotions", "Enron", "Scene", "Science", "Yeast", "Society", "Health", "Recreation", "Computers", "Reference", "Entertainment", "Social", "Corel5k", "Mediamill", "Bibtex"
                     , "Corel16k001", "Corel16k002", "Corel16k003", "Corel16k004", "Corel16k005", "Corel16k006", "Corel16k007", "Corel16k008", "Corel16k009", "Corel16k010", "3sources_bbc1000", "3sources_guardian1000", "3sources_inter3000",
                     "3sources_reuters1000", "20NG", "CAL500", "CHD_49", "EukaryoteGO", "EukaryotePseAAC", "Flags", "Langlog", "PlantGO", "PlantPseAAC", "Stackex_chemistry",  "Stackex_chess", "Stackex_coffee", "Stackex_cooking", "Stackex_cs", "Stackex_philosophy",
                     "foodtruck", "GnegativeGO", "GnegativePseAAC", "GpositiveGO", "GpositivePseAAC", "HumanGO", "HumanPseAAC", "Image", "Oshumed", "Reuters-K500", "Slashdot", "tmc2007-500", "VirusGO", "VirusPseAAC", "Water-quality", "Yelp", "Medical"]
    label_n_list = [26, 19, 30, 33, 6, 53, 6, 40, 14, 27, 32, 22, 33, 33, 21, 39, 374, 101, 159
                    , 153, 164, 154, 162, 160, 162, 174, 168, 173, 144, 6, 6, 6, 6, 20, 174, 6, 22, 22, 7, 75, 12, 12, 175,
                    227, 123, 400, 274, 233, 12, 8, 8, 4, 4, 14, 14, 5, 23, 103, 22, 22, 6, 6, 14, 5, 45]
    arff_file_is_sparse = [True, False, True, True, False, True, False, True, False, True, False, True, True, True,
                           True, True, False, False, True, False, False, False, False, False, False, False, False,
                           False, False, False, False, False, False, True, False, False, False, False, False, True, True, True, False,
                           False, False, False, False, False, False, True, True, True, True, True, True, False, True, True, True, True, True, True, False, False, True]
    selector_names = ["ppt_mi", "pmu", "mdmr", "scls", "gmm", "dcr_mfs", "lsmfs", "wfrfs", "rwfs", "mfs_mcdm", "test_21"]
    selector_names_upper = ["PPT+MI", "PMU", "MDMR", "SCLS", "GMM", "DCR-MFS", "LSMFS", "WFRFS", "RWFS", "MFS_MCDM", "LIWR-LDR"]
    bins = sys.argv[1]
    bins = int(bins)
    Classifier = "four_t"
    Classifier_fun = DT_predict
    result_path = "Experiment_result_"+Classifier+"_bins_" + str(bins) + "/"
    result_paths = ["Experiment_result_CC_bins_" + str(bins) + "/", "Experiment_result_MLKNN_bins_" + str(bins) + "/",
                    "Experiment_result_DT_bins_" + str(bins) + "/",
                    "Experiment_result_RF_bins_" + str(bins) + "/"]
    if not os.path.exists(result_path):
        os.mkdir(result_path)
    data_set_list = ["Yahoo_Business", "Yahoo_Education", "Yahoo_Science", "Yahoo_Society", "Yahoo_Computers", "Yahoo_Reference", "Yahoo_Health", "Corel5k", "Bibtex", "3sources_bbc1000", "Yahoo_Social", "3sources_reuters1000", "Stackex_chess", "Stackex_coffee", "Stackex_cs", "Oshumed", "Medical",
                     "VirusGO", "GnegativeGO", "Yahoo_Entertainment", "Slashdot", "Reuters-K500", "Corel16k003", "Corel16k007", "Corel16k010"]
    dataset_nickname = ["Bus", "Edu", "Sci", "Scy", "Com", "Ref", "Hea", "C5k", "Bib", "Bbc", "Scl", "R10", "Che", "Cof", "Cs", "Osh", "Med",
                     "Vir", "Gne", "Ent", "Sla", "RK5", "C03", "C07", "C10"]
    sorted_index = np.array(dataset_nickname).argsort()
    data_set_list = list(np.array(data_set_list)[sorted_index])
    dataset_nickname = list(np.array(dataset_nickname)[sorted_index])
    metric = ["micro_f1", "jaccard_score_micro", "hamming_loss", "one_error", "subSetAccuracy", "label_rank_average_precision"]
    metric_upper = ["Micro-F1", "Micro-Jaccard index", "Hamming loss", "One error", "Subset accuracy", "Average precision"]
    cvs = list(range(1, 6))
    for i in range(len(data_set_list)):
        histTable_four_cv(data_set_list[i], selector_names, result_paths, result_path, cvs)
        doDraw(data_set_list[i], dataset_nickname[i], selector_names, selector_names_upper, result_path, metric, metric_upper)

    sign_test(data_set_list, selector_names, metric, result_path, own=len(selector_names) - 1)
    for i in range(len(metric)):
        summary_table(data_set_list, selector_names, metric[i], result_path)
    for i in range(len(metric)):
        summary_table_str(data_set_list, dataset_nickname, selector_names, metric[i], result_path)

    drawFriedman(selector_names_upper, metric, metric_upper, result_path, own=len(selector_names) - 1)
    sum_friedman(selector_names, selector_names_upper, metric, metric_upper, result_path)


if __name__ == '__main__':
    setup()
