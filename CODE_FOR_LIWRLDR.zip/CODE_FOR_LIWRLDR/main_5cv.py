import sys
import warnings
from pathlib import Path

from sklearnex import patch_sklearn
patch_sklearn()

from numba import njit
from scipy import io
from scipy import sparse

from base.baseTools_cpu import ent, ent_2d
from drawPicture import *
from ex_classifier.classifier_predict import *
from feature_selection.DCR_MFS import dcr_mfs
from feature_selection.MFS_MCDM import MFS_MCDM
from feature_selection.GMM_cpu import gmm
from feature_selection.LSMFS_cpu import lsmfs
from feature_selection.MDMR_cpu import mdmr
from feature_selection.PMU_new import pmu
from feature_selection.PPT_CHI import ppt_chi
from feature_selection.PPT_MI import ppt_mi
from feature_selection.RWFS import rwfs
from feature_selection.SCLS_cpu import scls
from feature_selection.WFRFS import wfrfs
from feature_selection.CHAIN_repair import chain_repair
from feature_selection.test_21 import test_21
from load_data_set.process_arff import *
from log.experiment_log_v2 import *
import warnings
warnings.filterwarnings("ignore")


def load_dataset(bins, data_set, label_n, arff_file_is_sparse, cv=None, path = "data_sets_all"):
    X_train_d, y_train, X_test_d, y_test = process_data(data_set, label_n, arff_file_is_sparse, bins, cv = cv, path = path)
    return X_train_d, y_train, X_test_d, y_test


@njit
def get_mi(X, y):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    ent_f = np.zeros(feature_n)
    ent_l = np.zeros(label_n)
    base = 10
    mi = np.zeros(feature_n)
    ent_fl = np.zeros((feature_n, label_n))
    for i in range(feature_n):
        ent_f[i] = ent(X[:, i])
    for i in range(label_n):
        ent_l[i] = ent(y[:, i])
    for i in range(feature_n):
        for j in range(label_n):
            ent_fl[i, j] = ent_2d(base, X[:, i], y[:, j])
            mi[i] += ent_f[i] + ent_l[j] - ent_fl[i, j]
    return ent_f, ent_l, ent_fl, mi


def experiment(data_set, select_method, X_train, y_train, result_path, threshold=50, cv=None):
    if X_train.shape[1] < threshold:
        threshold = X_train.shape[1]
    for method in select_method:
        ent_f, ent_l, ent_fl, mi = get_mi(X_train, y_train)
        if method == "gmm":
            selected = gmm(X_train, y_train, threshold)
        elif method == "lsmfs":
            selected = lsmfs(X_train, y_train, ent_f, ent_l, ent_fl, mi, threshold)
        elif method == "scls":
            selected = scls(X_train, y_train, ent_f, ent_l, ent_fl, mi, threshold)
        elif method == "mdmr":
            selected = mdmr(X_train, y_train, ent_f, ent_l, ent_fl, mi, threshold)
        elif method == "mfs_mcdm":
            selected = MFS_MCDM(X_train, y_train).mfs_mcdm()
        elif method == "wfrfs":
            selected = wfrfs(X_train, y_train, threshold)
        elif method == "dcr_mfs":
            selected = dcr_mfs(X_train, y_train, ent_f, ent_l, ent_fl, mi, threshold)
        elif method == "enm":
            selected = enm(X_train, y_train, threshold)
        elif method == "rwfs":
            selected = rwfs(X_train, y_train, ent_f, ent_l, ent_fl, mi, threshold)
        elif method == "ppt_mi":
            selected = ppt_mi(X_train, y_train, threshold)
        elif method == "ppt_chi":
            selected = ppt_chi(X_train, y_train, threshold)
        elif method == "test_21":
            selected = test_21(X_train, y_train, ent_f, ent_l, ent_fl, mi, threshold)
        else:
            raise Exception("没有这个方法")
        np.savetxt(result_path + data_set + "_" + str(cv)+ "_" + method + "_Selected_feature", np.array(selected), delimiter=None)


def getResultIndex(data_set, select_method, X_train, y_train, X_test, y_test, result_path, threshold=50, Classifier=None, cv=None):
    for method in select_method:
        measure_result_h = []
        measure_result_mi = []
        measure_result_lrap = []
        measure_result_jaccard_mi = []
        measure_result_subset_accuracy = []
        measure_result_oe = []
        for count in range(1, threshold + 1):
            feature_select = np.loadtxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Selected_feature",
                                        delimiter=None)
            feature_index_iter = feature_select[:count].astype(int)
            X_temp_train = X_train[:, feature_index_iter]
            X_temp_test = X_test[:, feature_index_iter]
            if Classifier == MLKNN_predict:
                result, result_pro = MLKNN_predict(X_temp_train, y_train, X_temp_test, y_test, 10)
            else:
                result, result_pro = Classifier(X_temp_train, y_train, X_temp_test)
            measure_result_h_i = Classifier_score(result, result_pro, y_test, "hamming_loss")
            measure_result_mi_i = Classifier_score(result, result_pro, y_test, "micro_f1")
            measure_result_lrap_i = Classifier_score(result, result_pro, y_test, "label_rank_average_precision")
            measure_result_jaccard_mi_i = Classifier_score(result, result_pro, y_test, "jaccard_score_micro")
            measure_result_subset_accuracy_i = Classifier_score(result, result_pro, y_test, "subsetAccuracy")
            measure_result_oe_i = Classifier_score(result, result_pro, y_test, "one_error")

            measure_result_h.append(measure_result_h_i)
            measure_result_mi.append(measure_result_mi_i)
            measure_result_lrap.append(measure_result_lrap_i)
            measure_result_jaccard_mi.append(measure_result_jaccard_mi_i)
            measure_result_subset_accuracy.append(measure_result_subset_accuracy_i)
            measure_result_oe.append(measure_result_oe_i)

        np.savetxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Result_h", measure_result_h, delimiter=None)
        np.savetxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Result_mi", measure_result_mi, delimiter=None)
        np.savetxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Result_lrap", measure_result_lrap, delimiter=None)
        np.savetxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Result_jaccard_mi", measure_result_jaccard_mi, delimiter=None)
        np.savetxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Result_subSetAccuracy", measure_result_subset_accuracy, delimiter=None)
        np.savetxt(result_path + data_set + "_" + str(cv) + "_" + method + "_Result_oe", measure_result_oe, delimiter=None)



def histTable(data_set, cvs, metrics, selector_names, result_path):
    for metric in metrics:
        drawTable_cv(data_set, cvs, selector_names, metric, result_path)
    print("图完成")


def histTable_four(data_set, selector_names, result_paths, result_path):
    draw_table_four(data_set, selector_names, "hamming_loss", result_paths, result_path)
    draw_table_four(data_set, selector_names, "micro_f1", result_paths, result_path)
    draw_table_four(data_set, selector_names, "label_rank_average_precision", result_paths, result_path)
    draw_table_four(data_set, selector_names, "jaccard_score_micro", result_paths, result_path)
    draw_table_four(data_set, selector_names, "subSetAccuracy", result_paths, result_path)
    draw_table_four(data_set, selector_names, "one_error", result_paths, result_path)
    print("图完成")



def setup():
    # 主程序
    data_set_list_all = ["Yahoo_Arts", "birds", "Yahoo_Business", "Yahoo_Education", "Emotions", "Enron", "Scene", "Yahoo_Science", "Yeast", "Yahoo_Society", "Yahoo_Health", "Yahoo_Recreation", "Yahoo_Computers", "Yahoo_Reference", "Yahoo_Entertainment", "Yahoo_Social", "Corel5k", "Mediamill", "Bibtex"
                     , "Corel16k001", "Corel16k002", "Corel16k003", "Corel16k004", "Corel16k005", "Corel16k006", "Corel16k007", "Corel16k008", "Corel16k009", "Corel16k010", "3sources_bbc1000", "3sources_guardian1000", "3sources_inter3000",
                     "3sources_reuters1000", "20NG", "CAL500", "CHD_49", "EukaryoteGO", "EukaryotePseAAC", "Flags", "Langlog", "PlantGO", "PlantPseAAC", "Stackex_chemistry",  "Stackex_chess", "Stackex_coffee", "Stackex_cooking", "Stackex_cs", "Stackex_philosophy",
                     "foodtruck", "GnegativeGO", "GnegativePseAAC", "GpositiveGO", "GpositivePseAAC", "HumanGO", "HumanPseAAC", "Image", "Oshumed", "Reuters-K500", "Slashdot", "tmc2007-500", "VirusGO", "VirusPseAAC", "Water-quality", "Yelp", "Medical"]
    label_n_list = [26, 19, 30, 33, 6, 53, 6, 40, 14, 27, 32, 22, 33, 33, 21, 39, 374, 101, 159
                    , 153, 164, 154, 162, 160, 162, 174, 168, 173, 144, 6, 6, 6, 6, 20, 174, 6, 22, 22, 7, 75, 12, 12, 175,
                    227, 123, 400, 274, 233, 12, 8, 8, 4, 4, 14, 14, 5, 23, 103, 22, 22, 6, 6, 14, 5, 45]
    arff_file_is_sparse = [True, False, True, True, False, True, False, True, False, True, False, True, True, True,
                           True, True, False, False, True, False, False, False, False, False, False, False, False,
                           False, False, False, False, False, False, True, False, False, False, False, False, True, True, True, False,
                           False, False, False, False, False, False, True, True, True, True, True, True, False, True, True, True, True, True, True, False, False, True]
    selector_names = ["ppt_chi", "ppt_mi", "mdmr", "gmm", "dcr_mfs", "lsmfs", "wfrfs", "rwfs", "pmfs", "mfs_mcdm", "test_21"]
    selector_names_upper = ["PPT+CHI", "PPT+MI", "MDMR", "GMM", "DCR-MFS", "LSMFS", "WFRFS", "RWFS", "PMFS", "MFS_MCDM", "LIWR-LDR"]
    bins = sys.argv[1]
    bins = int(bins)
    Classifier = "RF"
    Classifier_fun = RF_predict
    result_path = "Experiment_result_"+Classifier+"_bins_" + str(bins) + "/"
    if not os.path.exists(result_path):
        os.mkdir(result_path)
    data_set_list = ["Yahoo_Business", "Yahoo_Education", "Yahoo_Science", "Yahoo_Society", "Yahoo_Computers", "Yahoo_Reference", "Yahoo_Health", "Corel5k", "Bibtex", "3sources_bbc1000", "Yahoo_Social", "3sources_reuters1000", "Stackex_chess", "Stackex_coffee", "Stackex_cs", "Oshumed", "Medical",
                     "VirusGO", "GnegativeGO", "Yahoo_Entertainment", "Slashdot","Corel16k003", "Corel16k007", "Corel16k010", "Reuters-K500"]

    dataset_nickname = ["Business", "Education", "Science", "Society", "Computers", "Reference", "Health", "Corel5k", "Bibtex", "3sources_bbc1000", "Social", "3sources_reuters1000", "Stackex_chess", "Stackex_coffee", "Stackex_cs", "Oshumed", "Medical",
                     "VirusGO", "GnegativeGO", "Entertainment", "Slashdot", "Corel16k003", "Corel16k007", "Corel16k010", "Reuters-K500"]
    sorted_index = np.array(dataset_nickname).argsort()
    data_set_list = list(np.array(data_set_list)[sorted_index])
    dataset_nickname = list(np.array(dataset_nickname)[sorted_index])
    metric = ["hamming_loss", "zero_one_loss", "micro_f1", "macro_f1", "ranking_loss", "coverage", "jaccard_score_macro", "jaccard_score_micro", "subSetAccuracy", "micro_auc", "one_error", "label_rank_average_precision", "micro_recall"]
    metric_upper = ["Hamming Loss", "Zero One Loss", "Micro F1", "Macro F1", "Ranking Loss", "Coverage Error", "Macro Jaccard Index", "Micro Jaccard Index", "Subset Accuracy", "Micro AUC", "One Error", "Average Precision", "micro_recall"]
    cvs = list(range(1, 6))
    for i in range(0, len(data_set_list)):
        for k in cvs:
            j = data_set_list_all.index(data_set_list[i])
            print(data_set_list[i], label_n_list[j], arff_file_is_sparse[j])
            X_train, y_train, X_test, y_test = load_dataset(bins, data_set_list[i], label_n_list[j], arff_file_is_sparse[j], cv=k, path = "S5cv")
            experiment(data_set_list[i], selector_names, X_train, y_train, result_path, cv=k)
            getResultIndex(data_set_list[i], selector_names, X_train, y_train, X_test, y_test, result_path, Classifier=Classifier_fun, cv=k)
        histTable(data_set_list[i], cvs, metric, selector_names, result_path)


if __name__ == '__main__':
    setup()
