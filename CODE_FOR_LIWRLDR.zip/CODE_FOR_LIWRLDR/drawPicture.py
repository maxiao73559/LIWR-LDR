from decimal import Decimal

import numpy as np
import os
import xlwt
from matplotlib.ticker import StrMethodFormatter
from matplotlib import pyplot as plt
import xlrd
from Orange.evaluation import *
import Orange
from scipy import stats


# def drowPicture(dataset_name, dataset_nickname, selector_names, selector_names_upper, metric, metric_nickname, markers, colors, result_path, M=50):
#     from matplotlib.font_manager import FontProperties
#     font = FontProperties(fname='TIMES.TTF')
#     lateral_axis = list(range(1, 51))
#     flag = ""
#     metric_str = ""
#     name = ""
#     arrow = "↑"
#     if metric == "hamming_loss":
#         metric_str = "Hamming loss"
#         name = "hl"
#         arrow = "↓"
#         flag = "_h"
#     elif metric == "zero_one_loss":
#         metric_str = "Zero One Loss"
#         arrow = "↓"
#         flag = "_z"
#     elif metric == "macro_f1":
#         metric_str = "Macro-F1"
#         name = "ma"
#         flag = "_ma"
#     elif metric == "micro_f1":
#         metric_str = "Micro-F1"
#         name = "mi"
#         flag = "_mi"
#     elif metric == "micro_recall":
#         metric_str = "Micro-Recall"
#         name = "mirc"
#         flag = "_rc"
#     elif metric == "ranking_loss":
#         metric_str = "Ranking loss"
#         name = "rl"
#         arrow = "↓"
#         flag = "_rank"
#     elif metric == "average_precision":
#         flag = "_ap"
#     elif metric == "coverage":
#         metric_str = "Coverage error"
#         name = "ce"
#         arrow = "↓"
#         flag = "_co"
#     elif metric == "macro_auc":
#         flag = "_ma_auc"
#     elif metric == "micro_auc":
#         metric_str = "Micro-AUC"
#         flag = "_mi_auc"
#     elif metric == "jaccard_score_macro":
#         flag = "_jaccard_ma"
#     elif metric == "jaccard_score_micro":
#         metric_str = "Micro-Jaccard Index"
#         flag = "_jaccard_mi"
#     elif metric == "subSetAccuracy":
#         name = "sa"
#         metric_str = "Subset accuracy"
#         flag = "_subSetAccuracy"
#     elif metric == "label_rank_average_precision":
#         metric_str = "Average precision"
#         name = "ap"
#         flag = "_lrap"
#     elif metric == "one_error":
#         arrow = "↓"
#         name = "oe"
#         metric_str = "One error"
#         flag = "_oe"
#     else:
#         Exception("不支持标准")
#     fig = plt.figure()
#     for i in range(len(selector_names)):
#         result = np.loadtxt(result_path + dataset_name + "_" + selector_names[i] + "_Result" + flag,
#                             delimiter=None)
#         direct_axis = result
#         plt.plot(lateral_axis, direct_axis, label=selector_names_upper[i], color=colors[i], linestyle='-', linewidth=1, marker=markers[i], markersize=4)
#     plt.title(dataset_nickname, fontsize=16, font=font)
#     plt.xticks(np.arange(0, M+1, 10), fontsize=16, font=font)
#     plt.xlabel('Number of selected features', fontsize=16, font=font)
#     # plt.ylabel(metric_str + "(" + arrow + ")", fontsize=16)
#     plt.ylabel(metric_nickname, fontsize=16, font=font)
#
#     plt.subplots_adjust(left=0, right=0.8, top=1, bottom=0)
#     # plt.legend()
#     # plt.legend(bbox_to_anchor=(1, 0), loc=3, borderaxespad=4, markerscale=0.5, ncol=6, prop={'size': 6})
#     plt.show()
#     fig.tight_layout()
#     # fig.savefig(result_path + dataset_nickname + '_of_' + name + "_of_mlknn" + ".eps", bbox_inches='tight', dpi=600, format='eps')
#     # fig.savefig(result_path + dataset_name  + "_" + metric + ".eps", bbox_inches='tight', dpi=600, format='eps')
#     if not os.path.exists(result_path + "../img/"):
#         os.mkdir(result_path + "../img/")
#     # fig.savefig(result_path + "../img/" + dataset_name  + "_" + metric + ".svg", bbox_inches='tight', dpi=600, format='svg')
#     fig.savefig(result_path + "../img/" + dataset_name  + "_" + metric + ".eps", bbox_inches='tight', dpi=600, format='eps')


def drowPicture(dataset_name, dataset_nickname, selector_names, selector_names_upper, metric, metric_str, markers,
                colors, result_path, M=50):
    lateral_axis = list(range(1, M + 1))
    flag = ""
    arrow = "↑"
    if metric == "hamming_loss":
        arrow = "↓"
        flag = "_h"
    elif metric == "zero_one_loss":
        arrow = "↓"
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "ranking_loss":
        arrow = "↓"
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        arrow = "↓"
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        arrow = "↓"
        flag = "_oe"
    else:
        Exception("不支持标准")
    fig = plt.figure()
    for i in range(len(selector_names)):
        # direct_axis = []
        result = np.loadtxt(result_path + dataset_name + "_" + selector_names[i] + "_Result" + flag, delimiter=None)
        # print(result)
        # for j in range(0, M, 2):
        #     direct_axis.append(result[j])
        direct_axis = result
        plt.plot(lateral_axis, direct_axis, label=selector_names_upper[i], color=colors[i], linestyle='-', linewidth=1, marker=markers[i], markersize=4)
    # plt.plot(lateral_axis)
    plt.gca().yaxis.set_major_formatter(StrMethodFormatter('{x:,.2f}'))
    plt.title(dataset_nickname, fontsize=20)
    plt.xticks(np.arange(0, M + 1, 10), fontsize=20)
    plt.xlabel('Number of selected features', fontsize=20)
    plt.yticks(fontsize=20)
    # plt.ylabel(metric_str + "(" + arrow + ")", fontsize=16)
    plt.ylabel(metric_str, fontsize=20)

    plt.subplots_adjust(left=0, right=0.8, top=1, bottom=0)
    # plt.legend(framealpha=0.5)
    # plt.legend(bbox_to_anchor=(1, 0), loc=3, borderaxespad=4, markerscale=0.5, ncol=6, prop={'size': 6})
    plt.show()
    # fig.savefig(result_path + "/img/" + dataset_name + '_' + metric + '.eps', bbox_inches='tight', dpi=600, format='eps')
    if not os.path.exists(result_path + "../img/"):
        os.mkdir(result_path + "../img/")
    # fig.savefig(result_path + "../img/" + dataset_name  + "_" + metric + ".svg", bbox_inches='tight', dpi=600, format='svg')
    fig.savefig(result_path + "../img/" + dataset_name  + "_" + metric + ".eps", bbox_inches='tight', dpi=600, format='eps')
    # fig.savefig(result_path + dataset_name + '_' + metric + '.svg', bbox_inches='tight', dpi=600, format='svg')
    # fig.savefig(result_path + dataset_name + '_' + metric + '.eps', bbox_inches='tight', dpi=600, format='eps')

def ablation_study(datasets, dataset_nicknames, selector_names, selector_names_upper, metric, markers, colors, result_path):
    lateral_axis = list(range(1, len(datasets) + 1))
    flag = ""
    metric_str = ""
    arrow = "↑"
    if metric == "hamming_loss":
        metric_str = "Hamming loss"
        arrow = "↓"
        flag = "_h"
    elif metric == "zero_one_loss":
        metric_str = "Zero One Loss"
        arrow = "↓"
        flag = "_z"
    elif metric == "macro_f1":
        metric_str = "Macro-F1"
        flag = "_ma"
    elif metric == "micro_f1":
        metric_str = "Micro-F1"
        flag = "_mi"
    elif metric == "micro_recall":
        metric_str = "Micro-Recall"
        flag = "_rc"
    elif metric == "ranking_loss":
        metric_str = "Ranking Loss"
        arrow = "↓"
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        arrow = "↓"
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        metric_str = "Micro-AUC"
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        metric_str = "Micro-jaccard index"
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        metric_str = "Accuracy"
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        metric_str = "Average precision"
        flag = "_lrap"
    elif metric == "one_error":
        arrow = "↓"
        metric_str = "One error"
        flag = "_oe"
    else:
        Exception("不支持标准")
    fig = plt.figure()
    book = xlrd.open_workbook(result_path + "result" + flag + "_mean.xls")
    sheet = book.sheets()[0]
    result = np.zeros((len(datasets), len(selector_names)))
    for i in range(len(selector_names)):

        for j in range(len(datasets)):
            row = sheet.row_values(j + 1)
            result[j, i] = (row[i * 3 + 1])
        # plt.plot(lateral_axis, direct_axis, label=selector_names_upper[i], color=colors[i], linestyle='-', linewidth=1, marker=markers[i], markersize=2)
    plt.boxplot(result, labels=selector_names_upper, sym='', medianprops={'color': 'blue'}, showmeans=True, meanprops={'marker': 'o', 'markeredgecolor': 'red', 'markerfacecolor': 'red'})

    # plt.plot(lateral_axis)
    # plt.title(dataset_nickname, fontsize=16)
    # plt.xticks(dataset_nicknames, fontsize=16)
    # plt.xticks(lateral_axis, dataset_nicknames, rotation=45, rotation_mode='anchor', fontsize=8, verticalalignment='top', horizontalalignment='right')
    # plt.xlabel('Number of selected features', fontsize=16)
    # plt.ylabel(metric_str + "(" + arrow + ")", fontsize=16)
    plt.ylabel(metric_str, fontsize=10)

    plt.subplots_adjust(left=0, right=0.8, top=1, bottom=0)
    # plt.legend()
    # plt.legend(bbox_to_anchor=(1, 0), loc=3, borderaxespad=4, ncol=11, prop={'size': 6})
    plt.show()
    fig.tight_layout()
    fig.savefig(result_path + "as" + '_' + metric + '.eps', bbox_inches='tight', dpi=600, format='eps')


def drawTable_cv(dataset_name, cvs, selector_names, metric, result_path):
    # 创建一个workbook 设置编码
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    flag = ""
    if metric == "hamming_loss":
        flag = "_h"
    elif metric == "zero_one_loss":
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "micro_recall":
        flag = "_rc"
    elif metric == "ranking_loss":
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        flag = "_oe"
    else:
        Exception("不支持标准")
    mean_list = []
    for i in range(len(selector_names)):
        for k in cvs:
            if k == cvs[0]:
                result = np.loadtxt(result_path + dataset_name + "_" + str(k) + "_" + selector_names[i] + "_Result" + flag,
                                delimiter=None)
            else:
                result += np.loadtxt(
                    result_path + dataset_name + "_" + str(k) + "_" + selector_names[i] + "_Result" + flag,
                    delimiter=None)
        result /= len(cvs)
        # 创建一个worksheet
        worksheet.write(0, i * 3, selector_names[i])
        worksheet.write(1, i * 3, np.mean(result))
        mean_list.append(np.mean(result))
        worksheet.write(1, i * 3 + 1, np.std(result))
    mean_list = np.array(mean_list)
    rank_t = np.argsort(mean_list)
    rank = np.zeros(rank_t.shape)
    rank_re_t = rank_t[::-1]
    rank_re = np.zeros(rank_re_t.shape)
    for i in range(rank_t.shape[0]):
        rank[rank_t[i]] = i
    for i in range(rank_re_t.shape[0]):
        rank_re[rank_re_t[i]] = i
    for i in range(len(selector_names)):
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 3 + 2, int(rank[i]))
        else:
            worksheet.write(1, i * 3 + 2, int(rank_re[i]))
        # 保存
    workbook.save(result_path + dataset_name + flag + '_mean.xls')
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test_max")
    for i in range(len(selector_names)):
        for k in cvs:
            if k == cvs[0]:
                result = np.loadtxt(result_path + dataset_name + "_" + str(k) + "_" + selector_names[i] + "_Result" + flag,
                                delimiter=None)
            else:
                result += np.loadtxt(
                    result_path + dataset_name + "_" + str(k) + "_" + selector_names[i] + "_Result" + flag,
                    delimiter=None)
        result /= len(cvs)
        # 创建一个worksheet
        worksheet.write(0, i * 2, selector_names[i])
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 2, np.min(result))
            worksheet.write(1, i * 2 + 1, int(np.argmin(result) + 1))
        else:
            worksheet.write(1, i * 2, np.max(result))
            worksheet.write(1, i * 2 + 1, int(np.argmax(result) + 1))
        # 保存
    workbook.save(result_path + dataset_name + flag + '_max.xls')


def drawTable(dataset_name, selector_names, metric, result_path):
    # 创建一个workbook 设置编码
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    flag = ""
    if metric == "hamming_loss":
        flag = "_h"
    elif metric == "zero_one_loss":
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "micro_recall":
        flag = "_rc"
    elif metric == "ranking_loss":
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        flag = "_oe"
    else:
        Exception("不支持标准")
    mean_list = []
    for i in range(len(selector_names)):
        result = np.loadtxt(result_path + dataset_name + "_" + selector_names[i] + "_Result" + flag,
                            delimiter=None)
        # 创建一个worksheet
        worksheet.write(0, i * 3, selector_names[i])
        worksheet.write(1, i * 3, np.mean(result))
        mean_list.append(np.mean(result))
        worksheet.write(1, i * 3 + 1, np.std(result))
    mean_list = np.array(mean_list)
    rank_t = np.argsort(mean_list)
    rank = np.zeros(rank_t.shape)
    rank_re_t = rank_t[::-1]
    rank_re = np.zeros(rank_re_t.shape)
    for i in range(rank_t.shape[0]):
        rank[rank_t[i]] = i
    for i in range(rank_re_t.shape[0]):
        rank_re[rank_re_t[i]] = i
    for i in range(len(selector_names)):
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 3 + 2, int(rank[i]))
        else:
            worksheet.write(1, i * 3 + 2, int(rank_re[i]))
        # 保存
    workbook.save(result_path + dataset_name + flag + '_mean.xls')
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test_max")
    for i in range(len(selector_names)):
        result = np.loadtxt(result_path + dataset_name + "_" + selector_names[i] + "_Result" + flag,
                            delimiter=None)
        # 创建一个worksheet
        worksheet.write(0, i * 2, selector_names[i])
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 2, np.min(result))
            worksheet.write(1, i * 2 + 1, int(np.argmin(result) + 1))
        else:
            worksheet.write(1, i * 2, np.max(result))
            worksheet.write(1, i * 2 + 1, int(np.argmax(result) + 1))
        # 保存
    workbook.save(result_path + dataset_name + flag + '_max.xls')


def draw_table_four(dataset_name, selector_names, metric, result_paths, result_path_four):
    # 创建一个workbook 设置编码
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    flag = ""
    if metric == "hamming_loss":
        flag = "_h"
    elif metric == "zero_one_loss":
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "micro_recall":
        flag = "_rc"
    elif metric == "ranking_loss":
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        flag = "_oe"
    else:
        Exception("不支持标准")
    mean_list = []
    for i in range(len(selector_names)):
        s = []
        j = 0
        worksheet.write(0, i * 3, selector_names[i])
        for result_path in result_paths:
            result = np.loadtxt(result_path + dataset_name + "_" + selector_names[i] + "_Result" + flag,
                                delimiter=None)
            # 创建一个worksheet
            s.append(result)
            j += 1
        s = np.mean(np.array(s), axis=0)
        np.savetxt(result_path_four + dataset_name + "_" + selector_names[i] + "_Result" + flag, s,
                                delimiter=None)
        worksheet.write(1, i * 3, np.mean(s))
        mean_list.append(np.mean(s))
        worksheet.write(1, i * 3 + 1, np.std(s))
    mean_list = np.array(mean_list)
    rank_t = np.argsort(mean_list)
    rank = np.zeros(rank_t.shape)
    rank_re_t = rank_t[::-1]
    rank_re = np.zeros(rank_re_t.shape)
    for i in range(rank_t.shape[0]):
        rank[rank_t[i]] = i
    for i in range(rank_re_t.shape[0]):
        rank_re[rank_re_t[i]] = i
        # 保存
    for i in range(len(selector_names)):
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 3 + 2, int(rank[i]))
        else:
            worksheet.write(1, i * 3 + 2, int(rank_re[i]))
    workbook.save(result_path_four + dataset_name + flag + '_mean.xls')

    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test_max")
    for i in range(len(selector_names)):
        result = np.loadtxt(result_path_four + dataset_name + "_" + selector_names[i] + "_Result" + flag,
                            delimiter=None)
        # 创建一个worksheet
        worksheet.write(0, i * 2, selector_names[i])
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 2, np.min(result))
            worksheet.write(1, i * 2 + 1, int(np.argmin(result) + 1))
        else:
            worksheet.write(1, i * 2, np.max(result))
            worksheet.write(1, i * 2 + 1, int(np.argmax(result) + 1))
    workbook.save(result_path_four + dataset_name + flag + '_max.xls')


def draw_table_four_cv(dataset_name, selector_names, metric, result_paths, result_path_four, cvs):
    # 创建一个workbook 设置编码
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    flag = ""
    if metric == "hamming_loss":
        flag = "_h"
    elif metric == "zero_one_loss":
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "micro_recall":
        flag = "_rc"
    elif metric == "ranking_loss":
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        flag = "_oe"
    else:
        Exception("不支持标准")
    mean_list = []
    for i in range(len(selector_names)):
        s = []
        j = 0
        worksheet.write(0, i * 3, selector_names[i])
        for result_path in result_paths:
            result = np.array([])
            for cv in cvs:
                if result.shape[0] == 0:
                    result = np.loadtxt(result_path + dataset_name + "_" + str(cv) + "_" + selector_names[i] + "_Result" + flag,
                                    delimiter=None)
                else:
                    result += np.loadtxt(result_path + dataset_name + "_" + str(cv) + "_" + selector_names[i] + "_Result" + flag,
                                    delimiter=None)
            # 创建一个worksheet
            s.append(result / 5)
            j += 1
        s = np.mean(np.array(s), axis=0)
        np.savetxt(result_path_four + dataset_name + "_" + selector_names[i] + "_Result" + flag, s,
                                delimiter=None)
        worksheet.write(1, i * 3, np.mean(s))
        mean_list.append(np.mean(s))
        worksheet.write(1, i * 3 + 1, np.std(s))
    mean_list = np.array(mean_list)
    rank_t = np.argsort(mean_list)
    rank = np.zeros(rank_t.shape)
    rank_re_t = rank_t[::-1]
    rank_re = np.zeros(rank_re_t.shape)
    for i in range(rank_t.shape[0]):
        rank[rank_t[i]] = i
    for i in range(rank_re_t.shape[0]):
        rank_re[rank_re_t[i]] = i
        # 保存
    for i in range(len(selector_names)):
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 3 + 2, int(rank[i]))
        else:
            worksheet.write(1, i * 3 + 2, int(rank_re[i]))
    workbook.save(result_path_four + dataset_name + flag + '_mean.xls')

    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test_max")
    for i in range(len(selector_names)):
        result = np.loadtxt(result_path_four + dataset_name + "_" + selector_names[i] + "_Result" + flag,
                            delimiter=None)
        # 创建一个worksheet
        worksheet.write(0, i * 2, selector_names[i])
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            worksheet.write(1, i * 2, np.min(result))
            worksheet.write(1, i * 2 + 1, int(np.argmin(result) + 1))
        else:
            worksheet.write(1, i * 2, np.max(result))
            worksheet.write(1, i * 2 + 1, int(np.argmax(result) + 1))
    workbook.save(result_path_four + dataset_name + flag + '_max.xls')



def summary_table(dataset_names,selector_names, metric, result_path, test="sign_rank"):
    # 创建一个workbook 设置编码
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    flag = ""
    if metric == "hamming_loss":
        flag = "_h"
    elif metric == "zero_one_loss":
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "micro_recall":
        flag = "_rc"
    elif metric == "ranking_loss":
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        flag = "_oe"
    else:
        Exception("不支持标准")
    for i in range(len(selector_names)):
        worksheet.write(0, i * 3 + 1, selector_names[i])
    if test == "sign_rank":
        t_book = xlrd.open_workbook(result_path + "sign_test" + flag + ".xls")
    else:
        t_book = xlrd.open_workbook(result_path + "t_test" + flag + ".xls")
    t_sheet = t_book.sheets()[0]
    # for j in range(len(dataset_names)):
    for j in range(len(dataset_names)):
        book = xlrd.open_workbook(result_path + dataset_names[j] + flag + "_mean.xls")
        sheet = book.sheets()[0]
        # 读取第一行
        row = sheet.row_values(1)
        t_row = t_sheet.row_values(j + 1)
        # 创建一个worksheet
        worksheet.write(j + 1, 0, dataset_names[j])
        for k in range(len(row)):
            worksheet.write(j + 1, k + 1, round(row[k], 4))
    # 保存
    workbook.save(result_path + "result" + flag+'_mean.xls')
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test_max")
    for i in range(len(selector_names)):
        worksheet.write(0, i * 2 + 1, selector_names[i])
    # for j in range(len(dataset_names)):
    for j in range(len(dataset_names)):
        book = xlrd.open_workbook(result_path + dataset_names[j] + flag + "_max.xls")
        sheet = book.sheets()[0]
        # 读取第一行
        row = sheet.row_values(1)
        # 创建一个worksheet
        worksheet.write(j + 1, 0, dataset_names[j])
        for k in range(len(row)):
            worksheet.write(j + 1, k + 1, row[k])

    # 保存
    print("成功")
    workbook.save(result_path + "result" + flag+'_max.xls')


def summary_runtime(dataset_names, dataset_names_upper, selector_names, result_path):
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    for i in range(len(selector_names)):
        worksheet.write(0, i + 1, selector_names[i])
    for j in range(len(dataset_names)):
        result = np.loadtxt(result_path + dataset_names[j] + "_runtime", delimiter=None)
        # 创建一个worksheet
        worksheet.write(j + 1, 0, dataset_names_upper[j])
        for k in range(len(result)):
            worksheet.write(j + 1, k + 1, Decimal(result[k]).quantize(Decimal("0.00")).to_eng_string())
    workbook.save(result_path + "runtime.xls")
    print("成功")


def summary_table_str(dataset_names, dataset_names_upper, selector_names, metric, result_path, test="sign_rank"):
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    flag = ""
    if metric == "hamming_loss":
        flag = "_h"
    elif metric == "zero_one_loss":
        flag = "_z"
    elif metric == "macro_f1":
        flag = "_ma"
    elif metric == "micro_f1":
        flag = "_mi"
    elif metric == "micro_recall":
        flag = "_rc"
    elif metric == "ranking_loss":
        flag = "_rank"
    elif metric == "average_precision":
        flag = "_ap"
    elif metric == "coverage":
        flag = "_co"
    elif metric == "macro_auc":
        flag = "_ma_auc"
    elif metric == "micro_auc":
        flag = "_mi_auc"
    elif metric == "jaccard_score_macro":
        flag = "_jaccard_ma"
    elif metric == "jaccard_score_micro":
        flag = "_jaccard_mi"
    elif metric == "subSetAccuracy":
        flag = "_subSetAccuracy"
    elif metric == "label_rank_average_precision":
        flag = "_lrap"
    elif metric == "one_error":
        flag = "_oe"
    else:
        Exception("不支持标准")
    for i in range(len(selector_names)):
        worksheet.write(0, i * 2 + 1, selector_names[i])
    if test == "sign_rank":
        t_book = xlrd.open_workbook(result_path + "sign_test" + flag + ".xls")
    else:
        t_book = xlrd.open_workbook(result_path + "t_test" + flag + ".xls")
    t_sheet = t_book.sheets()[0]
    AVG = np.zeros((len(dataset_names), len(selector_names)))
    wtl = np.zeros((3, len(selector_names)), dtype=int)
    for j in range(len(dataset_names)):
        book = xlrd.open_workbook(result_path + dataset_names[j] + flag + "_mean.xls")
        sheet = book.sheets()[0]
        # 读取第一行
        row = sheet.row_values(1)
        t_row = t_sheet.row_values(j + 1)
        t_row[len(t_row) - 1] = ''
        # 创建一个worksheet
        worksheet.write(j + 1, 0, dataset_names_upper[j])
        t = ''
        i = 0
        for k in range(len(row)):
            if k % 3 == 1:
                # 自己的方法
                if k == len(row) - 2:
                    worksheet.write(j + 1, i + 1,
                                    "$" + t + "\pm" + Decimal(round(row[k], 4)).quantize(
                                        Decimal("0.0000")).to_eng_string() +"$")
                else:
                    worksheet.write(j + 1, i + 1,
                                "$" + t + "\pm" + Decimal(round(row[k], 4)).quantize(Decimal("0.0000")).to_eng_string() + "(" +
                                t_row[k // 3 + 1] + ")$")
                    if t_row[k // 3 + 1] == '+':
                        wtl[0, k // 3] += 1
                    elif t_row[k // 3 + 1] == '=':
                        wtl[1, k // 3] += 1
                    elif t_row[k // 3 + 1] == '-':
                        wtl[2, k // 3] += 1
                i += 1
            else:
                if t == '':
                    t = Decimal(round(row[k], 4)).quantize(Decimal("0.0000")).to_eng_string()
                    AVG[j, k // 3] = round(row[k], 4)
                else:
                    worksheet.write(j + 1, i + 1, row[k])
                    t = ''
                    i += 1
    AVG = np.mean(AVG, axis=0)
    worksheet.write(len(dataset_names) + 1, 0, "AVG")
    for i in range(len(selector_names)):
        worksheet.write(len(dataset_names) + 1, i * 2 + 1, Decimal(AVG[i]).quantize(Decimal("0.0000")).to_eng_string())
    worksheet.write(len(dataset_names) + 2, 0, "W/T/L")
    for i in range(len(selector_names)):
        worksheet.write(len(dataset_names) + 2, i * 2 + 1, (str(wtl[0, i]) + "/" + str(wtl[1, i]) + "/" + str(wtl[2, i])))
    # 保存
    workbook.save(result_path + "result" + flag + '_mean_str.xls')
    print("成功")


def pickup(dataset_names,selector_names, metrics, result_path):
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    for i in range(len(selector_names)):
        worksheet.write(0, i + 1, selector_names[i])
    for i in range(len(dataset_names)):
        worksheet.write(i + 1, 0, dataset_names[i])
    pickup_result = np.zeros((len(dataset_names), len(selector_names)))
    for metric in metrics:
        flag = ""
        if metric == "hamming_loss":
            flag = "_h"
        elif metric == "zero_one_loss":
            flag = "_z"
        elif metric == "macro_f1":
            flag = "_ma"
        elif metric == "micro_f1":
            flag = "_mi"
        elif metric == "micro_recall":
            flag = "_rc"
        elif metric == "ranking_loss":
            flag = "_rank"
        elif metric == "average_precision":
            flag = "_ap"
        elif metric == "coverage":
            flag = "_co"
        elif metric == "macro_auc":
            flag = "_ma_auc"
        elif metric == "micro_auc":
            flag = "_mi_auc"
        elif metric == "jaccard_score_macro":
            flag = "_jaccard_ma"
        elif metric == "jaccard_score_micro":
            flag = "_jaccard_mi"
        elif metric == "subSetAccuracy":
            flag = "_subSetAccuracy"
        elif metric == "label_rank_average_precision":
            flag = "_lrap"
        elif metric == "one_error":
            flag = "_oe"
        else:
            Exception("不支持标准")
        # for j in range(len(dataset_names)):
        book = xlrd.open_workbook(result_path + "result" + flag + '_mean.xls')
        sheet = book.sheets()[0]
        name = []
        row = sheet.row_values(0)
        for i in range(len(row)):
            if row[i] != '':
                name.append(row[i])
        n_col = len(name)
        for j in range(1, len(dataset_names) + 1):
            # 读取第一行
            row = sheet.row_values(j)
            for k in range(1, n_col + 1):
                pickup_result[j - 1, k - 1] += row[k * 3]
            # 保存
    for i in range(pickup_result.shape[0]):
        for j in range(pickup_result.shape[1]):
            worksheet.write(i + 1, j + 1, pickup_result[i, j])
    workbook.save(result_path + "pickup.xls")


def t_test_cv(dataset_names, cvs, selector_names, metrics, result_path, own=0):
    for metric in metrics:
        workbook = xlwt.Workbook(encoding='utf-8')
        worksheet = workbook.add_sheet("test")
        for i in range(len(selector_names)):
            worksheet.write(0, i + 1, selector_names[i])
        for i in range(len(dataset_names)):
            worksheet.write(i + 1, 0, dataset_names[i])
        pickup_result = np.zeros((len(dataset_names), len(selector_names)), dtype=str)
        flag = ""
        if metric == "hamming_loss":
            flag = "_h"
        elif metric == "zero_one_loss":
            flag = "_z"
        elif metric == "macro_f1":
            flag = "_ma"
        elif metric == "micro_f1":
            flag = "_mi"
        elif metric == "micro_recall":
            flag = "_rc"
        elif metric == "ranking_loss":
            flag = "_rank"
        elif metric == "average_precision":
            flag = "_ap"
        elif metric == "coverage":
            flag = "_co"
        elif metric == "macro_auc":
            flag = "_ma_auc"
        elif metric == "micro_auc":
            flag = "_mi_auc"
        elif metric == "jaccard_score_macro":
            flag = "_jaccard_ma"
        elif metric == "jaccard_score_micro":
            flag = "_jaccard_mi"
        elif metric == "subSetAccuracy":
            flag = "_subSetAccuracy"
        elif metric == "label_rank_average_precision":
            flag = "_lrap"
        elif metric == "one_error":
            flag = "_oe"
        else:
            Exception("不支持标准")
        # for j in range(len(dataset_names)):
        dec = False
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            dec = True
        for j in range(1, len(dataset_names) + 1):
            # 读取第一行
            for k in cvs:
                if k == cvs[0]:
                    t1 = np.loadtxt(
                        result_path + dataset_names[j - 1] + "_" + str(k) + "_" + selector_names[own] + "_Result" + flag,
                        delimiter=None)
                else:
                    t1 += np.loadtxt(
                        result_path + dataset_names[j - 1] + "_" + str(k) + "_" + selector_names[own] + "_Result" + flag,
                        delimiter=None)
            t1 /= len(cvs)
            for k in range(len(selector_names) - 1):
                for l in cvs:
                    if l == cvs[0]:
                        t_i = np.loadtxt(
                            result_path + dataset_names[j - 1] + "_" + str(l) + "_" + selector_names[k] + "_Result" + flag,
                            delimiter=None)
                    else:
                        t_i += np.loadtxt(
                            result_path + dataset_names[j - 1] + "_" + str(l) + "_" + selector_names[k] + "_Result" + flag,
                            delimiter=None)
                t_i /= len(cvs)
                _, p = stats.ttest_rel(t1, t_i)
                if p >= 0.05:
                    pickup_result[j - 1, k] = '='
                elif dec:
                    if np.mean(t1) < np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
                else:
                    if np.mean(t1) > np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
            # 保存
        for i in range(pickup_result.shape[0]):
            for j in range(pickup_result.shape[1]):
                worksheet.write(i + 1, j + 1, pickup_result[i, j])
        workbook.save(result_path + "t_test" + flag + ".xls")


def sign_test_cv(dataset_names, cvs, selector_names, metrics, result_path, own=0):
    for metric in metrics:
        workbook = xlwt.Workbook(encoding='utf-8')
        worksheet = workbook.add_sheet("test")
        for i in range(len(selector_names)):
            worksheet.write(0, i + 1, selector_names[i])
        for i in range(len(dataset_names)):
            worksheet.write(i + 1, 0, dataset_names[i])
        pickup_result = np.zeros((len(dataset_names), len(selector_names)), dtype=str)
        flag = ""
        if metric == "hamming_loss":
            flag = "_h"
        elif metric == "zero_one_loss":
            flag = "_z"
        elif metric == "macro_f1":
            flag = "_ma"
        elif metric == "micro_f1":
            flag = "_mi"
        elif metric == "micro_recall":
            flag = "_rc"
        elif metric == "ranking_loss":
            flag = "_rank"
        elif metric == "average_precision":
            flag = "_ap"
        elif metric == "coverage":
            flag = "_co"
        elif metric == "macro_auc":
            flag = "_ma_auc"
        elif metric == "micro_auc":
            flag = "_mi_auc"
        elif metric == "jaccard_score_macro":
            flag = "_jaccard_ma"
        elif metric == "jaccard_score_micro":
            flag = "_jaccard_mi"
        elif metric == "subSetAccuracy":
            flag = "_subSetAccuracy"
        elif metric == "label_rank_average_precision":
            flag = "_lrap"
        elif metric == "one_error":
            flag = "_oe"
        else:
            Exception("不支持标准")
        # for j in range(len(dataset_names)):
        dec = False
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            dec = True
        for j in range(1, len(dataset_names) + 1):
            # 读取第一行
            for k in cvs:
                if k == cvs[0]:
                    t1 = np.loadtxt(
                        result_path + dataset_names[j - 1] + "_" + str(k) + "_" + selector_names[own] + "_Result" + flag,
                        delimiter=None)
                else:
                    t1 += np.loadtxt(
                        result_path + dataset_names[j - 1] + "_" + str(k) + "_" + selector_names[own] + "_Result" + flag,
                        delimiter=None)
            t1 /= len(cvs)
            for k in range(len(selector_names) - 1):
                for l in cvs:
                    if l == cvs[0]:
                        t_i = np.loadtxt(
                            result_path + dataset_names[j - 1] + "_" + str(l) + "_" + selector_names[k] + "_Result" + flag,
                            delimiter=None)
                    else:
                        t_i += np.loadtxt(
                            result_path + dataset_names[j - 1] + "_" + str(l) + "_" + selector_names[k] + "_Result" + flag,
                            delimiter=None)
                t_i /= len(cvs)
                _, p = stats.wilcoxon(t1, t_i)
                if p >= 0.05:
                    pickup_result[j - 1, k] = '='
                elif dec:
                    if np.mean(t1) < np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
                else:
                    if np.mean(t1) > np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
            # 保存
        for i in range(pickup_result.shape[0]):
            for j in range(pickup_result.shape[1]):
                worksheet.write(i + 1, j + 1, pickup_result[i, j])
        workbook.save(result_path + "sign_test" + flag + ".xls")


def sign_test(dataset_names, selector_names, metrics, result_path, own=0):
    for metric in metrics:
        workbook = xlwt.Workbook(encoding='utf-8')
        worksheet = workbook.add_sheet("test")
        for i in range(len(selector_names)):
            worksheet.write(0, i + 1, selector_names[i])
        for i in range(len(dataset_names)):
            worksheet.write(i + 1, 0, dataset_names[i])
        pickup_result = np.zeros((len(dataset_names), len(selector_names)), dtype=str)
        flag = ""
        if metric == "hamming_loss":
            flag = "_h"
        elif metric == "zero_one_loss":
            flag = "_z"
        elif metric == "macro_f1":
            flag = "_ma"
        elif metric == "micro_f1":
            flag = "_mi"
        elif metric == "micro_recall":
            flag = "_rc"
        elif metric == "ranking_loss":
            flag = "_rank"
        elif metric == "average_precision":
            flag = "_ap"
        elif metric == "coverage":
            flag = "_co"
        elif metric == "macro_auc":
            flag = "_ma_auc"
        elif metric == "micro_auc":
            flag = "_mi_auc"
        elif metric == "jaccard_score_macro":
            flag = "_jaccard_ma"
        elif metric == "jaccard_score_micro":
            flag = "_jaccard_mi"
        elif metric == "subSetAccuracy":
            flag = "_subSetAccuracy"
        elif metric == "label_rank_average_precision":
            flag = "_lrap"
        elif metric == "one_error":
            flag = "_oe"
        else:
            Exception("不支持标准")
        # for j in range(len(dataset_names)):
        dec = False
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            dec = True
        for j in range(1, len(dataset_names) + 1):
            # 读取第一行
            t1 = np.loadtxt(result_path + dataset_names[j - 1] + "_" + selector_names[own] + "_Result" + flag,
                            delimiter=None)
            for k in range(len(selector_names) - 1):
                t_i = np.loadtxt(result_path + dataset_names[j - 1] + "_" + selector_names[k] + "_Result" + flag,
                           delimiter=None)
                _, p = stats.wilcoxon(t1, t_i)
                if p >= 0.05:
                    pickup_result[j - 1, k] = '='
                elif dec:
                    if np.mean(t1) < np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
                else:
                    if np.mean(t1) > np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
            # 保存
        for i in range(pickup_result.shape[0]):
            for j in range(pickup_result.shape[1]):
                worksheet.write(i + 1, j + 1, pickup_result[i, j])
        workbook.save(result_path + "sign_test" + flag + ".xls")


def t_test(dataset_names, selector_names, metrics, result_path, own=0):
    for metric in metrics:
        workbook = xlwt.Workbook(encoding='utf-8')
        worksheet = workbook.add_sheet("test")
        for i in range(len(selector_names)):
            worksheet.write(0, i + 1, selector_names[i])
        for i in range(len(dataset_names)):
            worksheet.write(i + 1, 0, dataset_names[i])
        pickup_result = np.zeros((len(dataset_names), len(selector_names)), dtype=str)
        flag = ""
        if metric == "hamming_loss":
            flag = "_h"
        elif metric == "zero_one_loss":
            flag = "_z"
        elif metric == "macro_f1":
            flag = "_ma"
        elif metric == "micro_f1":
            flag = "_mi"
        elif metric == "ranking_loss":
            flag = "_rank"
        elif metric == "average_precision":
            flag = "_ap"
        elif metric == "coverage":
            flag = "_co"
        elif metric == "macro_auc":
            flag = "_ma_auc"
        elif metric == "micro_auc":
            flag = "_mi_auc"
        elif metric == "micro_recall":
            flag = "_rc"
        elif metric == "jaccard_score_macro":
            flag = "_jaccard_ma"
        elif metric == "jaccard_score_micro":
            flag = "_jaccard_mi"
        elif metric == "subSetAccuracy":
            flag = "_subSetAccuracy"
        elif metric == "label_rank_average_precision":
            flag = "_lrap"
        elif metric == "one_error":
            flag = "_oe"
        else:
            Exception("不支持标准")
        # for j in range(len(dataset_names)):
        dec = False
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            dec = True
        for j in range(1, len(dataset_names) + 1):
            # 读取第一行
            t1 = np.loadtxt(result_path + dataset_names[j - 1] + "_" + selector_names[own] + "_Result" + flag,
                            delimiter=None)
            for k in range(len(selector_names)):
                t_i = np.loadtxt(result_path + dataset_names[j - 1] + "_" + selector_names[k] + "_Result" + flag,
                           delimiter=None)
                _, p = stats.ttest_rel(t1, t_i)
                if p >= 0.05:
                    pickup_result[j - 1, k] = '='
                elif dec:
                    if np.mean(t1) < np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
                else:
                    if np.mean(t1) > np.mean(t_i):
                        pickup_result[j - 1, k] = '+'
                    else:
                        pickup_result[j - 1, k] = '-'
            # 保存
        for i in range(pickup_result.shape[0]):
            for j in range(pickup_result.shape[1]):
                worksheet.write(i + 1, j + 1, pickup_result[i, j])
        workbook.save(result_path + "t_test" + flag + ".xls")


def drawFriedman(selector_name, metrics, metric_upper, result_path, own=0):
    result = []
    cd = 0
    for metric in metrics:
        flag = ""
        metric_str = ""
        n = ""
        arrow = "↑"
        if metric == "hamming_loss":
            metric_str = "Hamming loss"
            n = "hl"
            arrow = "↓"
            flag = "_h"
        elif metric == "zero_one_loss":
            metric_str = "Zero One Loss"
            arrow = "↓"
            flag = "_z"
        elif metric == "macro_f1":
            metric_str = "Macro-F1"
            n = "maf1"
            flag = "_ma"
        elif metric == "micro_f1":
            metric_str = "Micro-F1"
            n = "mif1"
            flag = "_mi"
        elif metric == "micro_recall":
            metric_str = "Micro-Recall"
            n = "mirc"
            flag = "_rc"
        elif metric == "ranking_loss":
            metric_str = "Ranking loss"
            n = "rl"
            arrow = "↓"
            flag = "_rank"
        elif metric == "average_precision":
            flag = "_ap"
        elif metric == "coverage":
            metric_str = "Coverage error"
            n = "ce"
            arrow = "↓"
            flag = "_co"
        elif metric == "macro_auc":
            flag = "_ma_auc"
        elif metric == "micro_auc":
            metric_str = "Micro-AUC"
            flag = "_mi_auc"
        elif metric == "jaccard_score_macro":
            flag = "_jaccard_ma"
        elif metric == "jaccard_score_micro":
            metric_str = "Micro-jaccard index"
            flag = "_jaccard_mi"
        elif metric == "subSetAccuracy":
            n = "sa"
            metric_str = "Subset accuracy"
            flag = "_subSetAccuracy"
        elif metric == "label_rank_average_precision":
            metric_str = "Average precision"
            n = "ap"
            flag = "_lrap"
        elif metric == "one_error":
            arrow = "↓"
            n = "oe"
            metric_str = "One error"
            flag = "_oe"
        else:
            Exception("不支持标准")
        book = xlrd.open_workbook(result_path + "result" + flag+'_mean.xls')
        sheet = book.sheets()[0]
        # 读取第一行
        name = []
        row = sheet.row_values(0)

        for i in range(len(row)):
            if row[i] != '':
                name.append(row[i])
        n_col = len(name)
        val = np.zeros((sheet.nrows - 1, n_col))
        for i in range(1, sheet.nrows):
            row = sheet.row_values(i)
            for j in range(n_col):
                val[i - 1, j] = row[j * 3 + 1]
        if flag == "_h" or flag == "_rank" or flag == "_z" or flag == "_co" or flag == "_oe":
            result_i, cd = friedman(result_path, metric, n, np.array(selector_name), val, up=False, own=own)
            result.append(result_i)
        else:
            result_i, cd = friedman(result_path, metric, n, np.array(selector_name), val, own=own)
            result.append(result_i)
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    for i in range(len(metrics)):
        worksheet.write(i, 0, metric_upper[i])
        worksheet.write(i, 1, Decimal(result[i]).quantize(Decimal("0.0000")).to_eng_string())
    worksheet.write(0, 2, Decimal(cd).quantize(Decimal("0.0000")).to_eng_string())
    workbook.save(result_path + "img/" + "friedman_p.xls")


def friedman(result_path, metric, n, name, value, up=True, own=0):
    value = np.around(value, decimals=4)
    order = np.zeros(value.shape)
    for i in range(value.shape[0]):
        if up:
            order_t = value[i].argsort()[::-1]
            order_value = np.sort(value[i])[::-1]
        else:
            order_t = value[i].argsort()
            order_value = np.sort(value[i])
        j = 1
        while j <= order_value.shape[0]:
            k = j + 1
            while k <= order_value.shape[0]:
                if order_value[j - 1] == order_value[k - 1]:
                    k += 1
                else:
                    break
            x = j - 1
            temp = (j + k - 1) / 2
            while x < k - 1:
                order[i, order_t[x]] = temp
                x += 1
            j = k
    # q = studentized_range.ppf(1 - 0.05, value.shape[1], np.inf) / np.sqrt(2)
    # q = 2.773
    chi_F = 12 * value.shape[0] / (value.shape[1] * (value.shape[1] + 1)) * (np.sum(np.mean(order, axis=0)**2) - (value.shape[1] * ((value.shape[1] + 1) ** 2)) / 4)
    result = chi_F*(value.shape[0] - 1) / (value.shape[0]*(value.shape[1]-1) - chi_F)
    cv = stats.f.isf(q=0.05, dfn=value.shape[1] - 1, dfd=(value.shape[1] - 1) * (value.shape[0] - 1))
    print(value.shape[1] - 1, cv)
    # cd = q * np.sqrt(value.shape[1] * (value.shape[1] + 1) / (6 * value.shape[0]))
    order = np.mean(order, axis=0)
    np.savetxt(result_path + "_" + metric + "friedman", np.round(np.array(order), 2), delimiter=None)
    cd = compute_CD(order, value.shape[0], alpha='0.05', test='bonferroni-dunn')
    cd = round(cd, 4)
    # graph_ranks(order, name, cd=cd, cdmethod=own, textspace=1.5, filename=result_path+ "MCCFSof" + n + ".eps", dpi=600, format='eps')
    # graph_ranks(order, name, cd=cd, cdmethod=own, textspace=1.5, filename=result_path+ metric + ".eps", dpi=600, format='eps')
    if not os.path.exists(result_path + "img/"):
        os.mkdir(result_path + "img/")
    graph_ranks(order, name, cd=cd, cdmethod=own, textspace=1.5, filename=result_path + "img/" + metric + ".svg", dpi=600, format='svg')
    graph_ranks(order, name, cd=cd, cdmethod=own, textspace=1.5, filename=result_path + "img/" + metric + ".eps", dpi=600, format='eps')
    plt.show()
    return result, cv


def sum_friedman(selector_name, selector_name_upper, metrics, metric_upper, result_path):
    workbook = xlwt.Workbook(encoding='utf-8')
    worksheet = workbook.add_sheet("test")
    for i in range(len(selector_name)):
        worksheet.write(i + 1, 0, selector_name_upper[i])
    for i in range(len(metrics)):
        worksheet.write(0, i + 1, metric_upper[i])
    temp = np.zeros((len(selector_name), len(metrics)))
    for i in range(len(metrics)):
        temp[:, i] = np.loadtxt(result_path + "_" + metrics[i] + "friedman", delimiter=None)
        for j in range(len(selector_name)):
            worksheet.write(j + 1, i + 1, Decimal(temp[j, i]).quantize(Decimal("0.00")).to_eng_string())
    temp_mean = np.mean(temp, axis=1)
    for i in range(len(selector_name)):
        worksheet.write(i + 1, len(metrics) + 1, Decimal(temp_mean[i]).quantize(Decimal("0.00")).to_eng_string())
    # workbook.save(result_path + "friedman.xls")
    if not os.path.exists(result_path + "img/"):
        os.mkdir(result_path + "img/")
    workbook.save(result_path + "img/" + "friedman.xls")
