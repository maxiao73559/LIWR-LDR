from scipy import sparse
from sklearn import metrics
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from skmultilearn.problem_transform import BinaryRelevance
from skmultilearn.problem_transform import ClassifierChain

from ex_classifier.MLKNN import mlknn
import numpy as np


def DT_predict(X_train, y_train, X_test):
    temp_label = []
    temp_not_label = []
    for i in range(y_train.shape[1]):
        if len(np.unique(y_train[:, i])) != 1:
            temp_label.append(i)
        else:
            temp_not_label.append(i)

    classifier = BinaryRelevance(
        classifier=DecisionTreeClassifier(max_depth=5),
        require_dense=[False, True]
    )
    classifier.fit(X_train, y_train[:, temp_label])
    pre_t = np.array(classifier.predict(X_test).todense())
    pre_s_t = np.array(classifier.predict_proba(X_test).todense())
    pre = np.zeros((X_test.shape[0], y_train.shape[1]))
    pre_s = np.zeros((X_test.shape[0], y_train.shape[1]))
    for i in range(len(temp_label)):
        pre[:, temp_label[i]] = pre_t[:, i]
        pre_s[:, temp_label[i]] = pre_s_t[:, i]
    for i in range(len(temp_not_label)):
        if y_train[0, temp_not_label[i]] == 0:
            pre[:, temp_not_label[i]] = 0
            pre_s[:, temp_not_label[i]] = 0
        else:
            pre[:, temp_not_label[i]] = 1
            pre_s[:, temp_not_label[i]] = 1
    return pre, pre_s


def RF_predict(X_train, y_train, X_test):

    temp_label = []
    temp_not_label = []
    for i in range(y_train.shape[1]):
        if len(np.unique(y_train[:, i])) != 1:
            temp_label.append(i)
        else:
            temp_not_label.append(i)

    classifier = BinaryRelevance(
        classifier=RandomForestClassifier(),
        require_dense=[False, True]
    )
    classifier.fit(X_train, y_train[:, temp_label])
    pre_t = np.array(classifier.predict(X_test).todense())
    pre_s_t = np.array(classifier.predict_proba(X_test).todense())
    pre = np.zeros((X_test.shape[0], y_train.shape[1]))
    pre_s = np.zeros((X_test.shape[0], y_train.shape[1]))
    for i in range(len(temp_label)):
        pre[:, temp_label[i]] = pre_t[:, i]
        pre_s[:, temp_label[i]] = pre_s_t[:, i]
    for i in range(len(temp_not_label)):
        if y_train[0, temp_not_label[i]] == 0:
            pre[:, temp_not_label[i]] = 0
            pre_s[:, temp_not_label[i]] = 0
        else:
            pre[:, temp_not_label[i]] = 1
            pre_s[:, temp_not_label[i]] = 1
    return pre, pre_s


def MLKNN_predict(X_train, y_train, X_test, y_test, K):
    return mlknn(X_train, y_train, X_test, y_test, K)


def CC_predict(X_train, y_train, X_test):
    temp_label = []
    temp_not_label = []
    for i in range(y_train.shape[1]):
        if len(np.unique(y_train[:, i])) != 1:
            temp_label.append(i)
        else:
            temp_not_label.append(i)

    classifier = ClassifierChain(
        classifier=DecisionTreeClassifier(max_depth=5),
        require_dense=[False, True]
    )
    classifier.fit(X_train, y_train[:, temp_label])
    pre_t = np.array(classifier.predict(X_test).todense())
    pre_s_t = np.array(classifier.predict_proba(X_test).todense())
    pre = np.zeros((X_test.shape[0], y_train.shape[1]))
    pre_s = np.zeros((X_test.shape[0], y_train.shape[1]))
    for i in range(len(temp_label)):
        pre[:, temp_label[i]] = pre_t[:, i]
        pre_s[:, temp_label[i]] = pre_s_t[:, i]
    for i in range(len(temp_not_label)):
        if y_train[0, temp_not_label[i]] == 0:
            pre[:, temp_not_label[i]] = 0
            pre_s[:, temp_not_label[i]] = 0
        else:
            pre[:, temp_not_label[i]] = 1
            pre_s[:, temp_not_label[i]] = 1
    return pre, pre_s


def one_error(prediction_pro, y):
    count = 0
    for i in range(y.shape[0]):
        index = np.argmax(prediction_pro[i, :])
        if 1 != y[i, index]:
            count += 1
    return count / y.shape[0]


def Classifier_score(predictions, predictions_pro, y, metric):
    try:
        if metric == "hamming_loss":
            return metrics.hamming_loss(y, predictions)
        elif metric == "one_error":
            return one_error(predictions_pro, y)
        elif metric == "micro_f1":
            return metrics.f1_score(y, predictions, average="micro")
        elif metric == "jaccard_score_micro":
            return metrics.jaccard_score(y, predictions, average="micro")
        elif metric == "subsetAccuracy":
            return metrics.accuracy_score(y, predictions)
        elif metric == "label_rank_average_precision":
            return metrics.label_ranking_average_precision_score(y, predictions_pro)
        else:
            raise Exception("不支持的标准！")
    except ValueError:
        return 0

