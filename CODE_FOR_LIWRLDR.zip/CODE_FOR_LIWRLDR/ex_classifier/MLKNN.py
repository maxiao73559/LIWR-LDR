import numpy as np
from numba import njit
from sklearn.neighbors import NearestNeighbors


# def argsort(X, K):
#     min_k = np.zeros(K)
#     select_min = np.ones(X.shape[0])
#     for i in range(K):
#         t = np.inf
#         index = 0
#         for j in range(X.shape[0]):
#             if select_min[j] and X[j] < t:
#                 t = X[j]
#                 index = j
#         min_k[i] = index
#         select_min[index] = 0
#     return min_k
#
#
# def Knn(X_train, K):
#     neigh = np.zeros([X_train.shape[0], K])
#     dis = np.ones([X_train.shape[0], X_train.shape[0]]) * np.inf
#     for i in range(X_train.shape[0]):
#         for j in range(i+1, X_train.shape[0]):
#             dis[i, j] = np.sqrt(np.sum(np.square(X_train[i, :] - X_train[j, :])))
#             dis[j, i] = dis[i, j]
#     for i in range(X_train.shape[0]):
#         neigh[i, :] = argsort(dis[i, :], K)
#     return neigh
#
#
# def Knn_t(X_train, X_test, K):
#     neigh = np.zeros([X_test.shape[0], K])
#     dis = np.ones([X_test.shape[0], X_train.shape[0]]) * np.inf
#     for i in range(X_test.shape[0]):
#         for j in range(X_train.shape[0]):
#             dis[i, j] = np.sqrt(np.sum(np.square(X_test[i, :] - X_train[j, :])))
#     for i in range(X_test.shape[0]):
#         neigh[i, :] = argsort(dis[i, :], K)
#     return neigh

@njit
def calcCond(N_x, y_train, K, s):
    sample_train_n = y_train.shape[0]
    label_n = y_train.shape[1]
    cond = np.zeros((label_n, K + 1))
    condN = np.zeros((label_n, K + 1))
    for l in range(label_n):
        c = np.zeros(K + 1)
        cn = np.zeros(K + 1)
        for i in range(sample_train_n):
            delta = np.sum(y_train[N_x[i, :].astype(np.int32), l])
            if y_train[i, l] == 1:
                c[delta] += 1
            else:
                cn[delta] += 1
        for j in range(K + 1):
            cond[l, j] = (s + c[j]) / (s * (K + 1) + np.sum(c))
            condN[l, j] = (s + cn[j]) / (s * (K + 1) + np.sum(cn))
    return cond, condN


@njit
def get_predict(N_t, y_train, y_test, cond, condN, prior, priorN):
    sample_test_n = y_test.shape[0]
    label_n = y_test.shape[1]
    result = np.zeros(y_test.shape, dtype=np.uint8)
    result_pro = np.zeros(y_test.shape)
    for i in range(sample_test_n):
        for l in range(label_n):
            temp = np.sum(y_train[N_t[i, :].astype(np.int32), l])
            result[i, l] = int((prior[l] * cond[l, temp]) >= (priorN[l] * condN[l, temp]))
            result_pro[i, l] = (prior[l] * cond[l, temp]) / (prior[l] * cond[l, temp] + priorN[l] * condN[l, temp])
    return result, result_pro


def mlknn(X_train, y_train, X_test, y_test, K, s=1.0):
    sample_train_n = X_train.shape[0]
    sample_test_n = X_test.shape[0]
    label_n = y_train.shape[1]
    # Computing the prior probabilities
    prior = np.zeros(label_n)
    for i in range(label_n):
        prior[i] = (s + np.sum(y_train[:, i])) / (s * 2 + sample_train_n)
    priorN = 1 - prior
    # Compute the posterior probabilities
    # 计算领域矩阵
    # cond = np.zeros([label_n, K + 1])
    # condN = np.zeros([label_n, K + 1])
    # N_x = np.zeros((X_train.shape[0], K))
    neigh = NearestNeighbors(n_neighbors=K, p=2)
    neigh.fit(X_train)
    N_x = neigh.kneighbors(X_train, return_distance=False)
    # for i in range(X_train.shape[0]):
    #     neigh.fit(np.delete(X_train, i, 0))
    #     N_x[i, :] = neigh.kneighbors(np.array([X_train[i, :]]), return_distance=False)[0]
    # N_x = Knn(X_train, 10)
    # for l in range(label_n):
    #     c = np.zeros(K + 1)
    #     cn = np.zeros(K + 1)
    #     for i in range(sample_train_n):
    #         delta = np.sum(y_train[N_x[i, :].astype(int), l])
    #         if y_train[i, l] == 1:
    #             c[delta] += 1
    #         else:
    #             cn[delta] += 1
    #     for j in range(K + 1):
    #         cond[l, j] = (s + c[j]) / (s * (K + 1) + np.sum(c))
    #         condN[l, j] = (s + cn[j]) / (s * (K + 1) + np.sum(cn))
    cond, condN = calcCond(N_x, y_train, K, s)
    # 预测
    # result = np.zeros(y_test.shape, dtype=np.uint8)
    # result_pro = np.zeros(y_test.shape)
    neigh = NearestNeighbors(n_neighbors=K, p=2)
    neigh.fit(X_train)
    N_t = neigh.kneighbors(X_test, return_distance=False)
    # N_t = Knn_t(X_train, X_test, 10)
    # for i in range(sample_test_n):
    #     for l in range(label_n):
    #         temp = np.sum(y_train[N_t[i, :].astype(int), l])
    #         result[i, l] = int((prior[l] * cond[l, temp]) >= (priorN[l] * condN[l, temp]))
    #         result_pro[i, l] = (prior[l] * cond[l, temp]) / (prior[l] * cond[l, temp] + priorN[l] * condN[l, temp])
    # return result, result_pro
    return get_predict(N_t, y_train, y_test, cond, condN, prior, priorN)
