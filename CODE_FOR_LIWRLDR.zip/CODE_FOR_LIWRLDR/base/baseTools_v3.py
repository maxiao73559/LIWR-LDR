from numba import njit
import numpy as np


@njit
def ent(x):
    # 集合化X
    index = 0
    i = 0
    set_x = np.zeros(x.shape[0])
    count = np.zeros(x.shape[0])
    entropy = 0
    while i < x.shape[0]:
        j = 0
        while j < index:
            if set_x[j] == x[i]:
                break
            j += 1
        if j == index:
            set_x[j] = x[i]
            index += 1
        i += 1

    # 统计个数
    for i in range(index):
        count[i] = 0
        for j in range(x.shape[0]):
            if set_x[i] == x[j]:
                count[i] += 1

    # 计算概率
    for i in range(index):
        count[i] = count[i] / x.shape[0]

    # 计算熵
    for i in range(index):
        if count[i] != 0:
            entropy -= count[i] * np.log2(count[i])
    return entropy

@njit
def ent_2d(base, x, y):
    cat_x = x * base + y
    return ent(cat_x)


@njit
def ent_3d(base, x, y, z):
    cat_x = x * base * base + y * base + z
    return ent(cat_x)