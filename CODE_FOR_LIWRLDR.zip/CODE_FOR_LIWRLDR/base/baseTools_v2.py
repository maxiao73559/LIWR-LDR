import math

from numba import njit
import numpy as np


@njit
def ent(x):
    # 集合化X
    index = 0
    i = 0
    set_x = np.zeros(x.shape[0])
    count = np.zeros(x.shape[0])
    entropy = 0
    while i < x.shape[0]:
        j = 0
        while j < index:
            if set_x[j] == x[i]:
                break
            j += 1
        if j == index:
            set_x[j] = x[i]
            index += 1
        i += 1

    # 统计个数
    for i in range(index):
        count[i] = 0
        for j in range(x.shape[0]):
            if set_x[i] == x[j]:
                count[i] += 1

    # 计算概率
    for i in range(index):
        count[i] = count[i] / x.shape[0]

    # 计算熵
    for i in range(index):
        if count[i] != 0:
            entropy -= count[i] * np.log2(count[i])
    return entropy


@njit
def ent_2d(base, x, y):
    cat_x = x * base + y
    return ent(cat_x)


@njit
def ent_3d(base, x, y, z):
    cat_x = x * base * base + y * base + z
    return ent(cat_x)


@njit
def setize(x):
    # 集合化X
    index = 0
    i = 0
    set_x = np.zeros(x.shape[0])
    while i < x.shape[0]:
        j = 0
        while j < index:
            if set_x[j] == x[i]:
                break
            j += 1
        if j == index:
            set_x[j] = x[i]
            index += 1
        i += 1
    return set_x[:index]


@njit
def get_p(x, set_x):
    # 集合化X
    index = set_x.shape[0]
    count = np.zeros(x.shape[0])
    # 统计个数
    for i in range(index):
        count[i] = 0
        for j in range(x.shape[0]):
            if set_x[i] == x[j]:
                count[i] += 1
    # 计算概率
    for i in range(index):
        count[i] = count[i] / x.shape[0]
    return count[:index]


@njit
def get_mi(f, l):
    entropy = 0
    count = 0
    for i in range(l.shape[0]):
        if l[i] == 1:
            count += 1
    p_l = count / l.shape[0]
    set_1 = np.zeros(f.shape[0])
    n = 0
    for i in range(f.shape[0]):
        if l[i] == 1:
            set_1[n] = f[i]
            n += 1
    set_1 = setize(set_1[:n])
    n = set_1.shape[0]
    count = np.zeros(n)
    p_f = get_p(f, set_1)
    for i in range(n):
        for j in range(f.shape[0]):
            if l[j] == 1 and f[j] == set_1[i]:
                count[i] += 1
    for i in range(n):
        count[i] = count[i] / f.shape[0]
    for i in range(n):
        if count[i] != 0:
            entropy += count[i] * np.log2(count[i] / (p_f[i] * p_l))
    return entropy


@njit
def cmi_flf(f_i, f_j, l):
    set_f_i = setize(f_i)
    set_f_j = setize(f_j)
    p_f_i = get_p(f_i, set_f_i)
    cp_flf = np.zeros((set_f_i.shape[0], set_f_j.shape[0]))
    for i in range(set_f_i.shape[0]):
        for j in range(set_f_j.shape[0]):
            count = 0
            for k in range(f_i.shape[0]):
                if f_j[k] == set_f_j[j] and f_i[k] == set_f_i[i] and l[k] == 1:
                    count += 1
            cp_flf[i, j] = count / f_i.shape[0] / p_f_i[i]
    cp_lf = np.zeros(set_f_i.shape[0])
    for i in range(set_f_i.shape[0]):
        count = 0
        for j in range(f_i.shape[0]):
            if l[j] == 1 and f_i[j] == set_f_i[i]:
                count += 1
        cp_lf[i] = count / f_i.shape[0] / p_f_i[i]
    cp_ff = np.zeros((set_f_i.shape[0], set_f_j.shape[0]))
    for i in range(set_f_i.shape[0]):
        for j in range(set_f_j.shape[0]):
            count = 0
            for k in range(f_i.shape[0]):
                if f_i[k] == set_f_i[i] and f_j[k] == set_f_j[j]:
                    count += 1
            cp_ff[i, j] = count / f_i.shape[0] / p_f_i[i]
    cmi = 0
    for i in range(set_f_i.shape[0]):
        for j in range(set_f_j.shape[0]):
            if p_f_i[i] != 0 and cp_flf[i, j] != 0:
                cmi += p_f_i[i] * cp_flf[i, j] * np.log2(cp_flf[i, j] / (cp_ff[i, j] * cp_lf[i]))
    return cmi


@njit
def cmi_fll(f, l_i, l_j):
    set_f = setize(f)
    cp_ll = 0
    p_l = 0
    for i in range(l_i.shape[0]):
        if l_j[i] == 1:
            p_l += 1
            if l_i[i] == 1:
                cp_ll += 1
    if p_l == 0:
        return 0
    p_l = p_l / l_j.shape[0]
    cp_ll = cp_ll / l_j.shape[0] / p_l
    cp_fll = np.zeros(set_f.shape[0])
    for i in range(set_f.shape[0]):
        count = 0
        for j in range(f.shape[0]):
            if f[j] == set_f[i] and l_i[j] == 1 and l_j[j] == 1:
                count += 1
        cp_fll[i] = count / f.shape[0] / p_l
    cp_fl = np.zeros(set_f.shape[0])
    for i in range(set_f.shape[0]):
        count = 0
        for j in range(f.shape[0]):
            if f[j] == set_f[i] and l_j[j] == 1:
                count += 1
        cp_fl[i] = count / f.shape[0] / p_l
    cmi = 0
    for i in range(set_f.shape[0]):
        if cp_fll[i] != 0:
            cmi += p_l * cp_fll[i] * np.log2(cp_fll[i] / (cp_fl[i] * cp_ll))
    return cmi

# f1 = np.array([1, 0, 1, 0, 1, 1, 0])
# f2 = np.array([1, 0, 0, 1, 0, 1, 0])
# l0 = np.array([1, 0, 1, 1, 1, 0, 0])
# l1 = np.array([0, 0, 0, 1, 0, 0, 1])
#
#
# print(cmi_fll(f1, l0, l1))
# print(1/7 * np.log2(3/2) + 2/7 * np.log2(2) + 1/7 * np.log2(3/4))
# print(1/7 * np.log2(7/12) + 3/7 * np.log2(21/16))


@njit
def ii_fll(f, l_i, l_j):

    return get_mi(f, l_i) - cmi_fll(f, l_i, l_j)


@njit
def ii_ffl(f_i, f_j, l):

    return get_mi(f_j, l) - cmi_flf(f_i, f_j, l)
