#### This article is the experimental code for Multi-label feature selection considering label importance-weighted relevance and label-dependency redundancy.

- Setup of running environment

  `pip3 install -r requirements.txt `

- To execute the experiment, run `main_5cv.py`

  `python main_5cv.py [discretize the size of the bins]`

  note:`[]`is parameter.

- To plot, run `main.py`

  `python main.py [discretize the size of the bins]`