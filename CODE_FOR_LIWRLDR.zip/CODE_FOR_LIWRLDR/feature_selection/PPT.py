import numpy as np


# 转换方法
# def PPT(X, y):
#     i = 0
#     index = 0
#     set_x = np.zeros(y.shape, dtype=bool)
#     count = np.zeros(y.shape[0])
#     class_index = np.zeros(y.shape[0])
#     X_ppt = X.copy()
#     while i < y.shape[0]:
#         j = 0
#         while j < index:
#             if not np.count_nonzero(set_x[j, :] ^ y[i, :]):
#                 break
#             j += 1
#         if j == index:
#             set_x[j] = y[i]
#             index += 1
#         i += 1
#
#     # 统计个数
#     for i in range(index):
#         count[i] = 0
#         for j in range(y.shape[0]):
#             if not np.count_nonzero(set_x[i, :] ^ y[j, :]):
#                 count[i] += 1
#                 class_index[j] = i
#
#     # 计算概率
#     for i in range(index):
#         count[i] = count[i] / y.shape[0]
#
#     # 设置阈值
#     threshold1 = 1 / index
#     threshold2 = 0.1
#     threshold = max(threshold1, threshold2)
#
#
#     # 消除标记
#     for j in range(index):
#         if count[i] < threshold:
#             class_index[i] = -1
#
#     # 拆分
#     i = 0
#     while i < index:
#         if class_index[i] == -1:
#             for j in range(index):
#                 if class_index[j] != -1 and (not np.count_nonzero((set_x[j, :] | y[i, :]) - set_x[j, :])):
#                     X_ppt.rowstack((X[i, :]))
#                     np.append(class_index, class_index[j])
#
#     # 消除
#     X_ppt = X_ppt[class_index != -1]
#     class_index = class_index[class_index != -1]
#     return X_ppt, class_index

def PPT(y):
    i = 0
    index = 0
    set_x = []
    class_index = np.zeros(y.shape[0])
    while i < y.shape[0]:
        j = 0
        while j < index:
            if not np.count_nonzero(np.array(set_x[j]) ^ y[i, :]):
                break
            j += 1
        if j == index:
            set_x.append(y[i, :])
            index += 1
        i += 1

    # 统计个数
    count = np.zeros(index)
    for i in range(index):
        count[i] = 0
        for j in range(y.shape[0]):
            if not np.count_nonzero(np.array(set_x[i]) ^ y[j, :]):
                count[i] += 1
                class_index[j] = i

    # 计算概率
    for i in range(index):
        count[i] = count[i] / y.shape[0]

    # 设置阈值
    threshold1 = 1 / index
    threshold2 = 0.1
    threshold = min(threshold1, threshold2)

    # 消除标记
    flag = np.ones(index, dtype=bool)
    for i in range(index):
        if count[i] < threshold:
            flag[i] = 0

    #
    swap = np.arange(index)
    rest = np.arange(index)[flag]
    for i in range(index):
        if not flag[i]:
            s = np.zeros(index)
            for j in range(index):
                s[j] = np.count_nonzero(np.array(set_x[i]) - np.array(set_x[j]))
            t = s[flag].argmin()
            swap[i] = rest[t]

    for i in range(y.shape[0]):
        class_index[i] = swap[int(class_index[i])]

    return class_index
