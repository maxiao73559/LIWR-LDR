import os

import numpy as np
import scipy.io
import time
from sklearn.preprocessing import MinMaxScaler

from base.baseTools_cpu import ent


class MFS_MCDM():
    def __init__(self, X, y, **opt):
        self.X = X
        self.y = y

        self.num_sample = X.shape[0]
        self.num_feature = X.shape[1]
        self.num_label = y.shape[1]

        if "lambda_" in opt:
            self.lambda_ = opt["lambda_"]
        else:
            self.lambda_ = 10

    def TOPSIS(self, W, V):
        W_ = W * V
        A_star = np.max(W_, axis=0)
        A_ = np.min(W_, axis=0)
        AP = (W_ - A_star)**2
        S_star = np.sqrt(np.sum(AP, axis=1))
        AN = (W_ - A_)**2
        S_ = np.sqrt(np.sum(AN, axis=1))
        RC = S_/(S_star + S_)
        return RC

    def mfs_mcdm(self):
        t = time.time()
        print("开始计算W:" + str(t))
        W = np.linalg.inv(self.X.T @ self.X + self.lambda_ * np.eye(self.num_feature)) @ self.X.T @ self.y
        t = time.time()
        print("结束计算W:" + str(t))
        V = np.zeros(self.num_label)
        for i in range(self.num_label):
            V[i] = ent(self.y[:, i])
        V_ = V / np.sum(V)
        RC = self.TOPSIS(W, V_)
        select = RC.argsort()[::-1]
        return select

    @staticmethod
    def test():

        X = np.array([[1, 1, 0, 0, 0],
                     [0, 0, 0, 1, 0],
                     [1, 0, 1, 0, 0],
                     [0, 0, 0, 0, 1]])

        y = np.array([[1, 0, 0, 0],
                     [1, 1, 1, 0],
                     [0, 1, 0, 0],
                     [1, 0, 0, 1]])

        TrainSetSize = np.ceil(X.shape[0] * 0.8).astype(int)
        # scaler = MinMaxScaler()
        # scaler.fit(X)
        # X = scaler.transform(X)
        X_train = X[:TrainSetSize]
        y_train = y[:TrainSetSize]
        select = MFS_MCDM(X_train, y_train).mfs_mcdm()
        print(select)


# MFS_MCDM.test()
