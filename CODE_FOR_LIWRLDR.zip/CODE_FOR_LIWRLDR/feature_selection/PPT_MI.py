from base.baseTools_cpu import *
from feature_selection.PPT import PPT


def ppt_mi(X, y, threshold):
    mi = np.zeros(X.shape[1])
    c = PPT(y)
    ent_c = ent(c)
    ent_f = np.zeros(X.shape[1])
    for i in range(X.shape[1]):
        ent_f[i] = ent(X[:, i])
    base = 10
    for i in range(X.shape[1]):
        ent_fc = ent_2d(base, X[:, i], c)
        mi[i] = ent_f[i] + ent_c - ent_fc
    rank_f = mi.argsort()[::-1]
    select = rank_f[:threshold]
    return select
