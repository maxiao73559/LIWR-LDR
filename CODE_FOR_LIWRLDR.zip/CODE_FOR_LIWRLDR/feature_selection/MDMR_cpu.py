from base.baseTools_cpu import *


@njit
def get_second(X, y, ent_f, ent_fl, select, fk, ii, mi_ff):
    label_n = y.shape[1]
    base = 10
    for i in range(X.shape[1]):
        isNot = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isNot = False
        if isNot:
            ent_ff = ent_2d(base, X[:, fk], X[:, i])
            mi_ff[i] += ent_f[i] + ent_f[fk] - ent_ff
            for k in range(label_n):
                ent_ffl = ent_3d(base, X[:, i], X[:, fk], y[:, k])
                ii[i] += - ent_f[fk] + ent_ff + ent_fl[fk, k] - ent_ffl
    return ii, mi_ff


def mdmr(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    select = []
    nSelect = list(range(X.shape[1]))
    mi_ff = np.zeros(X.shape[1])
    ii = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(mi)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            mi_ = mi[nSelect]
            # 未选和已选特征
            ii, mi_ff = get_second(X, y, ent_f, ent_fl, np.array(select), fk, ii, mi_ff)
            mi_ff_i = mi_ff[nSelect]
            ii_i = ii[nSelect]
            fk_index = np.argmax(mi_ - (mi_ff_i - ii_i) / len(select))
            fk = nSelect.pop(fk_index)
            select.append(fk)
    return select
