import time
from base.baseTools_cpu import *


@njit
def get_CMI_fll(X, y, ent_f, ent_l, ent_fl):
    cmi_fll = np.zeros(X.shape[1])
    base = 10
    ent_ll = np.zeros((y.shape[1], y.shape[1]))
    for i in range(y.shape[1]):
        for j in range(i, y.shape[1]):
            ent_ll[i, j] = ent_2d(base, y[:, j], y[:, i])
            ent_ll[j, i] = ent_ll[i, j]
    for i in range(X.shape[1]):
        for j in range(y.shape[1]):
            for k in range(y.shape[1]):
                if j != k:
                    ent_fll = ent_3d(base, X[:, i], y[:, j], y[:, k])
                    cmi_fll[i] += - ent_l[k] + ent_fl[i, k] + ent_ll[j, k] - ent_fll
    return cmi_fll


@njit
def get_dynamic_item(X, y, cmi_flf, mi_ff, ent_f, ent_fl, select, fk):
    base = 10
    for i in range(X.shape[1]):
        isNotIn = True
        for j in range(select.shape[0]):
            if select[j] == i:
                isNotIn = False
                break
        if isNotIn:
            ent_ff = ent_2d(base, X[:, fk], X[:, i])
            mi_ff[i] += ent_f[i] + ent_f[fk] - ent_ff
            for j in range(y.shape[1]):
                ent_flf = ent_3d(base, X[:, i], y[:, j], X[:, fk])
                cmi_flf[i] += -ent_f[fk] + ent_fl[fk, j] + ent_ff - ent_flf
    return cmi_flf, mi_ff


def dcr_mfs(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    cmi_fll = get_CMI_fll(X, y, ent_f, ent_l, ent_fl,)
    select = []
    nSelect = list(range(X.shape[1]))
    mi_ff = np.zeros(X.shape[1])
    cmi_flf = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(cmi_fll)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            cmi_flf, mi_ff = get_dynamic_item(X, y, cmi_flf, mi_ff, ent_f, ent_fl, np.array(select), fk)
            # 未选和已选特征
            jk = (cmi_fll + cmi_flf - mi_ff)
            jk = jk[nSelect]
            fk_index = np.argmax(jk)
            fk = nSelect[fk_index]
            select.append(fk)
            nSelect.remove(fk)

        print('len(F): ', len(select))
        print('F: ', select)
        print('fk: ', fk)
        s = time.asctime(time.localtime(time.time()))
        print("THE FS END OF Time  : ", s)
        print('----------------------------------------------------------------------')
    return select
