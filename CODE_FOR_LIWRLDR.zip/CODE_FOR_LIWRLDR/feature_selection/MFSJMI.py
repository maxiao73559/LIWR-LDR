from numba import njit
from base.baseTools_cpu import *
import time


@njit
def get_II_fll(X, y, ent_f, ent_l, ent_fl):

    fr = np.zeros(X.shape[1])
    mi = np.zeros((X.shape[1], y.shape[1]))
    base = 10

    for i in range(X.shape[1]):
        for j in range(y.shape[1]):
            mi[i, j] = ent_f[i] + ent_l[j] - ent_fl[i, j]

    ent_ll = np.zeros((y.shape[1], y.shape[1]))
    for i in range(y.shape[1]):
        for j in range(y.shape[1]):
            ent_ll[i, j] = ent_2d(base, y[:, i], y[:, j])

    for i in range(X.shape[1]):
        for j in range(y.shape[1]):
            for k in range(y.shape[1]):
                if j != k:
                    if mi[i, j] != 0:
                        ent_fll = ent_3d(base, X[:, i], y[:, j], y[:, k])
                        ii_fll = ent_f[i] + ent_l[j] + ent_l[k] - ent_fl[i, j] - ent_fl[i, k] - ent_ll[j, k] + ent_fll
                        jmi = - ent_l[j] - ent_fll + ent_ll[j, k] + ent_fl[i, j] + mi[i, j]
                        if ii_fll > 0:
                            fr[i] += (ii_fll / mi[i, j]) * jmi
                        else:
                            fr[i] += (1 - ii_fll / mi[i, j]) * jmi
    return fr


@njit
def get_II_ffl(X, y, ent_f, ent_l, ent_fl, select, fk, ii):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    base = 10
    for i in range(feature_n):
        isIn = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isIn = False
                break
        if isIn:
            ent_ff = ent_2d(base, X[:, i], X[:, fk])
            ii[i] += ent_f[i] + ent_f[fk] - ent_ff
    return ii


def mfsjmi(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    ii_fll = get_II_fll(X, y, ent_f, ent_l, ent_fl)
    first = ii_fll
    select = []
    nSelect = list(range(X.shape[1]))
    ii = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(first)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来

            # 未选和已选特征
            ii = get_II_ffl(X, y, ent_f, ent_l, ent_fl, np.array(select), fk,  ii)
            jk = (first - ii)
            jk = jk[nSelect]
            fk_index = np.argmax(jk)
            fk = nSelect[fk_index]
            select.append(fk)
            nSelect.remove(fk)

        print('len(F): ', len(select))
        print('F: ', select)
        print('fk: ', fk)
        s = time.asctime(time.localtime(time.time()))
        print("THE FS END OF Time  : ", s)
        print('----------------------------------------------------------------------')

    return select
