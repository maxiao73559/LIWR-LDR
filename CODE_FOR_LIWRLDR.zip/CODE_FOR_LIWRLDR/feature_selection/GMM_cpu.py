from base.baseTools_cpu import *


@njit
def get_jk(X, y):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    ent_x = np.zeros(feature_n)
    ent_y = np.zeros(label_n)
    base = 10
    mi = np.ones(feature_n)
    for i in range(feature_n):
        ent_x[i] = ent(X[:, i])
        if ent_x[i] == 0:
            mi[i] = 0
    for i in range(label_n):
        ent_y[i] = ent(y[:, i])
    for i in range(feature_n):
        for j in range(label_n):
            ent_xy = ent_2d(base, X[:, i], y[:, j])
            mi_i = ent_x[i] + ent_y[j] - ent_xy
            if np.abs(mi_i) > 1e-10:
                mi[i] *= mi_i
            # else:
            #     mi[i] *= 0.0000000001
    return np.power(mi, 1 / label_n)


def gmm(X, y, threshold):
    jk = get_jk(X, y)
    np.savetxt("enm_j", np.array(jk))
    rank_f = jk.argsort()[::-1]
    select = rank_f[:threshold]
    return select
