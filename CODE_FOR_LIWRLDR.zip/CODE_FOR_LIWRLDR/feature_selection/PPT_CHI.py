import numpy as np
from sklearn.utils import as_float_array

from feature_selection.PPT import PPT
from sklearn import feature_selection


def ppt_chi(X, y, threshold):
    c = PPT(y)
    scores, _ = feature_selection.chi2(X, c)
    scores = as_float_array(scores, copy=True)
    scores[np.isnan(scores)] = np.finfo(scores.dtype).min
    # model1 = SelectKBest(chi2, k=1)  # 选择k个最佳特征
    # _ = model1.fit_transform(X, c)  # x是特征数据，y是标签数据，该函数可以选择出k个特征
    # res = model1.get_support(indices=True)  # 返回k个最佳特征的索引
    # return list(res)
    rank_f = scores.argsort(kind="mergesort")[::-1]
    select = rank_f[:threshold]
    return select
