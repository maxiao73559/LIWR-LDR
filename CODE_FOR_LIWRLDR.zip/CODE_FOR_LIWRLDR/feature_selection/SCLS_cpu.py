from base.baseTools_cpu import *

@njit
def get_second(X, y, ent_f, select, fk, second_item):
    base = 10
    for i in range(X.shape[1]):
        # 是候选特征
        isNot = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isNot = False
        if isNot:
            ent_ff = ent_2d(base, X[:, i], X[:, fk])
            mi_ff = ent_f[i] + ent_f[fk] - ent_ff
            if ent_f[i] != 0:
                second_item[i] += mi_ff / ent_f[i]
    return second_item


def scls(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    select = []
    nSelect = list(range(X.shape[1]))
    second_item = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(mi)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            mi_i = mi[nSelect]
            # 未选和已选特征
            second_item = get_second(X, y, ent_f, np.array(select), fk, second_item)
            second_item_i = second_item[nSelect]
            fk_index = np.argmax(mi_i * (1 - second_item_i))
            fk = nSelect.pop(fk_index)
            select.append(fk)
    return select
