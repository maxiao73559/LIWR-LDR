
from base.baseTools_cpu import *


@njit
def get_cmi_llf(X, y, ent_fl, ent_f, ent_l):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    cmi_llf = np.zeros(X.shape[1])
    base = 10
    mi_all = np.zeros((feature_n, label_n))
    mi_ll = np.zeros((label_n, label_n))
    for i in range(label_n):
        for j in range(label_n):
            ent_ll = ent_2d(base, y[:, i], y[:, j])
            mi_ll[i, j] = ent_l[i] + ent_l[j] - ent_ll
    for i in range(feature_n):
        for j in range(label_n):
            mi_all[i, j] = ent_f[i] + ent_l[j] - ent_fl[i, j]
    for i in range(feature_n):
        for j in range(label_n):
            for k in range(label_n):
                cmi_llf[i] += mi_ll[j, k] * mi_all[i, j]
    return cmi_llf, mi_all


@njit
def get_second(X, y, ent_f, mi_all, select, fk, second_item):
    base = 10
    for i in range(X.shape[1]):
        # 是候选特征
        isNot = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isNot = False
        if isNot:
            ent_ff = ent_2d(base, X[:, i], X[:, fk])
            mi_ff = ent_f[i] + ent_f[fk] - ent_ff
            for j in range(y.shape[1]):
                if ent_f[fk] != 0:
                    second_item[i] += (mi_all[fk, j] / ent_f[fk]) * mi_ff
    return second_item


def test_21(X, y, ent_f, ent_l, ent_fl, mi,  threshold):
    cmi_llf, mi_all = get_cmi_llf(X, y, ent_fl, ent_f, ent_l)
    first = cmi_llf
    select = []
    nSelect = list(range(X.shape[1]))
    second_item = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(first)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            first_i = first[nSelect]
            # 未选和已选特征
            second_item = get_second(X, y, ent_f, mi_all, np.array(select), fk, second_item)
            mi_ff_i = second_item[nSelect]
            fk_index = np.argmax(first_i - mi_ff_i)
            fk = nSelect.pop(fk_index)
            select.append(fk)
    return select
