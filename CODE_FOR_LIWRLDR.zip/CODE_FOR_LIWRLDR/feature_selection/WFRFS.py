import time

from base.baseTools_cpu import *


@njit
def get_mi(X, y):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    ent_f = np.zeros(feature_n)
    ent_l = np.zeros(label_n)
    base = 10
    mi_sum = np.zeros(feature_n)
    mi = np.zeros((feature_n, label_n))
    ent_fl = np.zeros((feature_n, label_n))
    for i in range(feature_n):
        ent_f[i] = ent(X[:, i])
    for i in range(label_n):
        ent_l[i] = ent(y[:, i])
    for i in range(feature_n):
        for j in range(label_n):
            ent_fl[i, j] = ent_2d(base, X[:, i], y[:, j])
            mi[i, j] = ent_f[i] + ent_l[j] - ent_fl[i, j]
            mi_sum[i] += mi[i, j]
    return ent_f, ent_l, ent_fl, mi_sum, mi


@njit
def get_weight(weight, ent_fl, ent_f, ent_l, fk):
    # 计算权重
    for i in range(weight.shape[0]):
        if ent_l[i] == 0:
            weight_i = 0
        else:
            weight_i = (ent_fl[fk, i] - ent_f[fk]) / ent_l[i]
        weight[i] += weight_i
    return weight


@njit
def get_first(mi, weight, ent_f, ent_l, ent_fl, fk, nSelect):
    first = np.zeros(ent_f.shape[0])
    weight = get_weight(weight, ent_fl, ent_f, ent_l, fk)
    for i in range(mi.shape[0]):
        isIn = False
        for j in range(nSelect.shape[0]):
            if nSelect[j] == i:
                isIn = True
                break
        if isIn:
            for j in range(mi.shape[1]):
                first[i] += weight[j] * mi[i, j]
    return weight, first


@njit
def get_mi_ff(X, ent_f, select, fk, mi_ff):
    base = 10
    for i in range(X.shape[1]):
        isNotIn = True
        for j in range(select.shape[0]):
            if select[j] == i:
                isNotIn = False
                break
        if isNotIn:
            ent_ff = ent_2d(base, X[:, fk], X[:, i])
            mi_ff[i] += ent_f[i] + ent_f[fk] - ent_ff
    return mi_ff


def wfrfs(X, y, threshold):
    ent_f, ent_l, ent_fl, mi_sum, mi = get_mi(X, y)
    select = []
    nSelect = list(range(X.shape[1]))
    mi_ff = np.zeros(X.shape[1])
    weight = np.zeros(y.shape[1])
    for i in range(threshold):
        if i == 0:
            fk = np.argmax(mi_sum)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            weight, first = get_first(mi, weight, ent_f, ent_l, ent_fl, fk, np.array(nSelect))
            mi_ff = get_mi_ff(X, ent_f, np.array(select), fk, mi_ff)
            # 未选和已选特征
            jk = (first - mi_ff)
            jk = jk[nSelect]
            fk_index = np.argmax(jk)
            fk = nSelect[fk_index]
            select.append(fk)
            nSelect.remove(fk)

        print('len(F): ', len(select))
        print('F: ', select)
        print('fk: ', fk)
        s = time.asctime(time.localtime(time.time()))
        print("THE FS END OF Time  : ", s)
        print('----------------------------------------------------------------------')
    return select
