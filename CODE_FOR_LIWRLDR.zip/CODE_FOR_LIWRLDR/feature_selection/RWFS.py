from numba import njit
from base.baseTools_cpu import *
import time


@njit
def get_mi(X, y, ent_f, ent_l, ent_fl):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    mi = np.zeros((feature_n, label_n))
    for i in range(feature_n):
        for j in range(label_n):
            mi[i, j] = ent_f[i] + ent_l[j] - ent_fl[i, j]
    return mi


@njit
def getRW(X, y, ent_f, ent_l, ent_fl, select, fk, mi, ff, rw):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    base = 10
    for i in range(feature_n):
        isIn = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isIn = False
                break
        if isIn:
            ent_ff = ent_2d(base, X[:, i], X[:, fk])
            ff[i] += ent_f[fk] + ent_f[i] - ent_ff
            for k in range(label_n):
                ent_ffl = ent_3d(base, X[:, i], X[:, fk], y[:, k])
                if np.abs(mi[fk, k]) > 1e-10:
                    rw[i] += (ent_fl[fk, k] + ent_ff - ent_ffl - ent_f[fk]) + (ent_fl[i, k] + ent_ff - ent_ffl - ent_f[i]) * mi[i, k] / mi[fk, k]
                else:
                    rw[i] += (ent_fl[fk, k] + ent_ff - ent_ffl - ent_f[fk])
    return ff, rw


def rwfs(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    mi_each = get_mi(X, y, ent_f, ent_l, ent_fl)
    select = []
    nSelect = list(range(X.shape[1]))
    rw = np.zeros(X.shape[1])
    ff = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(mi)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来

            # 未选和已选特征
            ff, rw = getRW(X, y, ent_f, ent_l, ent_fl, np.array(select), fk, mi_each, ff, rw)
            jk = (rw / (len(select) * y.shape[1]) - ff / (len(select)))
            jk = jk[nSelect]
            fk_index = np.argmax(jk)
            fk = nSelect[fk_index]
            select.append(fk)
            nSelect.remove(fk)

        print('len(F): ', len(select))
        print('F: ', select)
        print('fk: ', fk)
        s = time.asctime(time.localtime(time.time()))
        print("THE FS END OF Time  : ", s)
        print('----------------------------------------------------------------------')

    return select
