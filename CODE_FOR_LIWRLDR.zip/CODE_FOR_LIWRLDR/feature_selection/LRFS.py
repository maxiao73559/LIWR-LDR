from numba import njit
from base.baseTools_cpu import *
import time


@njit
def get_first(X, y, ent_f, ent_l, ent_fl):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    base = 10
    ent_ll = np.zeros((label_n, label_n))
    for i in range(label_n):
        for j in range(i+1, label_n):
            ent_ll[i, j] = ent_2d(base, y[:, i], y[:, j])
    first = np.zeros(feature_n)
    for i in range(feature_n):
        for j in range(label_n):
            for k in range(label_n):
                if j != k:
                    ent_fll = ent_3d(base, X[:, i], y[:, j], y[:, k])
                    temp = - ent_l[k] + ent_fl[i, k] + ent_ll[j, k] - ent_fll
                    first[i] += temp
    return first


def get_J(X,ent_f, select, fk, mi_ff):
    feature_n = X.shape[1]
    base = 10
    for i in range(feature_n):
        isIn = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isIn = False
                break
        if isIn:
            ent_ff = ent_2d(base, X[:, i], X[:, fk])
            mi_ff[i] += ent_f[i] + ent_f[fk] - ent_ff
    return mi_ff


def lrfs(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    first = get_first(X, y, ent_f, ent_l, ent_fl)
    select = []
    nSelect = list(range(X.shape[1]))
    mi_ff = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(first)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            # 未选和已选特征
            mi_ff = get_J(X,ent_f, np.array(select), fk, mi_ff)
            Jk = first - (y.shape[1] / len(select)) * mi_ff
            jk = Jk[nSelect]
            fk_index = np.argmax(jk)
            fk = nSelect[fk_index]
            select.append(fk)
            nSelect.remove(fk)

        print('len(F): ', len(select))
        print('F: ', select)
        print('fk: ', fk)
        s = time.asctime(time.localtime(time.time()))
        print("THE FS END OF Time  : ", s)
        print('----------------------------------------------------------------------')

    return select
