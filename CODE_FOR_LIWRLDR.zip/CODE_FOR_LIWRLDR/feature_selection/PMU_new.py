from numba import njit
from base.baseTools_cpu import *
import time


@njit
def get_II_fll(X, y, ent_f, ent_l, ent_fl):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    ii = np.zeros(feature_n)
    list_yy = np.zeros((label_n * (label_n - 1) // 2, 2), dtype=np.int32)
    n = 0
    base = 10
    for i in range(label_n):
        j = i + 1
        while j < label_n:
            list_yy[n, 0] = i
            list_yy[n, 1] = j
            j += 1
            n += 1
    for i in range(feature_n):
        for j in range(list_yy.shape[0]):
            ent_ll = ent_2d(base, y[:, list_yy[j, 0]], y[:, list_yy[j, 1]])
            ent_fll = ent_3d(base, X[:, i], y[:, list_yy[j, 0]], y[:, list_yy[j, 1]])
            ii[i] += (ent_f[i] + ent_l[list_yy[j, 0]] + ent_l[list_yy[j, 1]] - \
                      ent_fl[i, list_yy[j, 0]] - ent_fl[i, list_yy[j, 1]] - \
                      ent_ll + ent_fll)
    return ii * 2


@njit
def get_II_ffl(X, y, ent_f, ent_l, ent_fl, select, fk, ii):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    base = 10
    for i in range(feature_n):
        isIn = True
        for j in range(select.shape[0]):
            if i == select[j]:
                isIn = False
                break
        if isIn:
            ent_ff = ent_2d(base, X[:, i], X[:, fk])
            for k in range(label_n):
                ent_ffl = ent_3d(base, X[:, i], X[:, fk], y[:, k])
                ii[i] += ent_f[i] + ent_f[fk] + ent_l[k] - \
                         ent_fl[i, k] - ent_fl[fk, k] - \
                         ent_ff + ent_ffl
    return ii


def pmu(X, y, ent_f, ent_l, ent_fl, mi, threshold):
    ii_fll = get_II_fll(X, y, ent_f, ent_l, ent_fl)
    first = mi - ii_fll
    select = []
    nSelect = list(range(X.shape[1]))
    ii = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(first)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来

            # 未选和已选特征
            ii = get_II_ffl(X, y, ent_f, ent_l, ent_fl, np.array(select), fk,  ii)
            jk = (first - ii)
            jk = jk[nSelect]
            fk_index = np.argmax(jk)
            fk = nSelect[fk_index]
            select.append(fk)
            nSelect.remove(fk)

        print('len(F): ', len(select))
        print('F: ', select)
        print('fk: ', fk)
        s = time.asctime(time.localtime(time.time()))
        print("THE FS END OF Time  : ", s)
        print('----------------------------------------------------------------------')

    return select
