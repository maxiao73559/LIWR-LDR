from base.baseTools_cpu import *


@njit
def get_II_fll(X, y, ent_f, ent_l, ent_fl):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    ii = np.zeros(feature_n)
    list_yy = np.zeros((label_n * (label_n - 1) // 2, 2), dtype=np.int32)
    n = 0
    base = 10
    for i in range(label_n):
        j = i + 1
        while j < label_n:
            list_yy[n, 0] = i
            list_yy[n, 1] = j
            j += 1
            n += 1
    for i in range(feature_n):
        for j in range(list_yy.shape[0]):
            ent_ll = ent_2d(base, y[:, list_yy[j, 0]], y[:, list_yy[j, 1]])
            ent_fll = ent_3d(base, X[:, i], y[:, list_yy[j, 0]], y[:, list_yy[j, 1]])
            temp = - (ent_f[i] + ent_l[list_yy[j, 0]] + ent_l[list_yy[j, 1]] - \
                      ent_fl[i, list_yy[j, 0]] - ent_fl[i, list_yy[j, 1]] - \
                      ent_ll + ent_fll)
            if temp > 0:
                ii[i] += temp
    for i in range(ii.shape[0]):
        ii[i] = ii[i] * 2
    return ii


@njit
def get_II_fll_slow(X, y, ent_f, ent_l, ent_fl):
    feature_n = X.shape[1]
    label_n = y.shape[1]
    ii = np.zeros(feature_n)
    n = 0
    base = 10
    for i in range(feature_n):
        for j in range(label_n):
            for k in range(label_n):
                if j != k:
                    ent_ll = ent_2d(base, y[:, j], y[:, k])
                    ent_fll = ent_3d(base, X[:, i], y[:, j], y[:, k])
                    temp = - ent_f[i] - ent_l[j] - ent_l[k] + ent_fl[i, j] + ent_fl[i, k] + ent_ll - ent_fll
                    if temp > 0:
                        ii[i] += temp
    return ii


@njit
def get_mi_ff(X, ent_f, select, fk, mi_ff):
    base = 10
    for i in range(X.shape[1]):
        isNotIn = True
        for j in range(select.shape[0]):
            if select[j] == i:
                isNotIn = False
                break
        if isNotIn:
            ent_ff = ent_2d(base, X[:, fk], X[:, i])
            mi_ff[i] += ent_f[i] + ent_f[fk] - ent_ff
    return mi_ff


def lsmfs(X, y,  ent_f, ent_l, ent_fl, mi, threshold):
    ii = get_II_fll_slow(X, y, ent_f, ent_l, ent_fl)
    first = mi + ii
    select = []
    nSelect = list(range(X.shape[1]))
    mi_ff = np.zeros(X.shape[1])
    for i in range(threshold):
        print(i)
        if i == 0:
            fk = np.argmax(first)
            select.append(fk)
            nSelect.remove(fk)
        else:
            # 将未选特征的第一项第三项分出来
            first_i = first[nSelect]
            # 未选和已选特征
            mi_ff = get_mi_ff(X, ent_f, np.array(select), fk, mi_ff)
            mi_ff_i = mi_ff[nSelect]
            fk_index = np.argmax(first_i - mi_ff_i)
            fk = nSelect.pop(fk_index)
            select.append(fk)
    return select
