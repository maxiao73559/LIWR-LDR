"""
做一些数据的加载和处理工作
"""
import os

import numpy as np
import pandas as pd
from scipy import io
from skmultilearn.dataset import load_from_arff

from load_data_set.arff_block import *


def process_data_all(data_set_name, label_number, arff_file_is_sparse=True):
    """
    :param arff_file_is_sparse:
    :param label_number:
    :param data_set_name: 数据集的名称
    :return: 训练集和测试集
    """
    path = "data_sets_all"
    is_exists = os.path.exists(path)
    if not is_exists:
        Exception("路径出错")

    label_count = label_number
    path_to_arff_file = path + '/' + data_set_name + '.arff'
    label_location = "end"

    X, y = load_from_arff(
        path_to_arff_file,
        label_count=label_count,
        label_location=label_location,
        load_sparse=arff_file_is_sparse,
    )

    X = np.array(X.todense())
    y = np.array(y.todense())

    return X, y


def process_data(data_set_name, label_number, arff_file_is_sparse=False, bins=3, cv=None, path = "data_sets_all"):
    """
    :param arff_file_is_sparse:
    :param label_number:
    :param data_set_name: 数据集的名称
    :return: 训练集和测试集
    """
    is_exists = os.path.exists(path)
    if not is_exists:
        Exception("路径出错")

    label_count = label_number
    path_to_arff_file_train = path + '/' + data_set_name + '-train.arff'
    path_to_arff_file_test = path + '/' + data_set_name + '-test.arff'
    if cv is not None:
        path_to_arff_file_train = path + '/' + data_set_name + '-train'+ str(cv) +'.arff'
        path_to_arff_file_test = path + '/' + data_set_name + '-test'+ str(cv) +'.arff'
    label_location = "end"
    if data_set_name == "20NG" or data_set_name == "Reuters-K500":
        label_location = "start"
    X_train, y_train = load_from_arff(
        path_to_arff_file_train,
        label_count=label_count,
        label_location=label_location,
        load_sparse=arff_file_is_sparse,
    )

    X_test, y_test = load_from_arff(
        path_to_arff_file_test,
        label_count=label_count,
        label_location=label_location,
        load_sparse=arff_file_is_sparse,
    )

    # 这个数据集有点小问题
    if data_set_name == "genbase":
        X_train = X_train[:, 1:]
        X_test = X_test[:, 1:]

    X_train = np.array(X_train.todense())
    X_test = np.array(X_test.todense())
    y_train = np.array(y_train.todense())
    y_test = np.array(y_test.todense())

    X_d = np.concatenate((X_train, X_test), 0)
    if not is_dis(data_set_name):
        print("离散化")
        X_d = discretize(X_d, bins, data_set_name)
    X_train_d = X_d[:X_train.shape[0], :]
    X_test_d = X_d[X_train.shape[0]:, :]
    X_train_d = np.ascontiguousarray(X_train_d)
    X_test_d = np.ascontiguousarray(X_test_d)
    X_train_d = X_train_d.astype(np.uint8)
    X_test_d = X_test_d.astype(np.uint8)
    y_train = y_train.astype(np.uint8)
    y_test = y_test.astype(np.uint8)

    return X_train_d, y_train, X_test_d, y_test


def is_dis(data_set_name):
    with open("data_sets_all/"+data_set_name+"-train.arff") as file:
        temp = file.readline()
        temp = temp.split()
        while not temp or temp[0] != "@attribute":
            temp = file.readline()
            temp = temp.split()
        if temp[2] == "numeric":
            return False
        else:
            return True


def is_dis_list(data_set_name):
    is_dis_list = []
    with open("data_sets_all/"+data_set_name+"-train.arff") as file:
        temp = file.readline()
        temp = temp.split()
        while not temp or temp[0] != "@attribute":
            temp = file.readline()
            temp = temp.split()
        while temp and temp[0] == "@attribute":
            if temp[2] == "numeric":
                is_dis_list.append(False)
            else:
                is_dis_list.append(True)
            temp = file.readline()
            temp = temp.split()
    return is_dis_list


def discretize(X, bins, data_set_name):
    # 初始化离散的数据
    dis = is_dis_list(data_set_name)
    X_dis = np.zeros(X.shape)
    for i in range(X.shape[1]):
        if not dis[i]:
            X_dis[:, i] = pd.cut(X[:, i], bins=bins, labels=False)
        else:
            X_dis[:, i] = X[:, i]
    return X_dis

