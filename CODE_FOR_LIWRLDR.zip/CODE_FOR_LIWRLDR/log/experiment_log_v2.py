from pathlib import Path
import os


def modifyLogOnlyIsClassifyBatch(result_path, bins, dataSet, method):
    method_list = []
    for i in range(len(dataSet)):
        method_list.append(method)
    modifyLogOnlyIsClassify(result_path, bins, dataSet, method_list)


def modifyLogOnlyIsClassify(result_path, bins, dataSet, method):
    filename = result_path + str(bins) + "/log.txt"
    opType = "w"
    dataSets, feature_selection = fetchLog(filename)
    for i in dataSet:
        for method_i in method:
            for j in method_i:
                if i in dataSets:
                    for k in range(len(feature_selection[dataSets.index(i)])):
                        if feature_selection[dataSets.index(i)][k]["method"] == j:
                            feature_selection[dataSets.index(i)][k]["isOver"] = 0
    _reWriteLog(filename, opType, dataSets, feature_selection)


def removeBatch(result_path, bins, dataSet, method):
    method_list = []
    for i in range(len(dataSet)):
        method_list.append(method)
    removeLog(result_path, bins, dataSet, method_list)


# 移除某个方法的结果
def removeLog(result_path, bins, dataSet, method):
    filename = result_path + str(bins) + "/log.txt"
    opType = "w"
    dataSets, feature_selection = fetchLog(filename)
    for i in dataSet:
        for method_i in method:
            for j in method_i:
                if i in dataSets:
                    isRemove = False
                    for k in range(len(feature_selection[dataSets.index(i)])):
                        if feature_selection[dataSets.index(i)][k]["method"] == j:
                            isRemove = True
                            break
                    if isRemove:
                        feature_selection[dataSets.index(i)].pop(k)
    _reWriteLog(filename, opType, dataSets, feature_selection)


# 初始化记录文件
def _initlogFile(result_path, filename, opType, bins, dataSet, method, threshold):
    metric = ["_h", "_z", "_mi", "_ma", "_rank", "_co", "_jaccard_ma", "_jaccard_mi", "_subSetAccuracy", "_ap", "_mi_auc", "_oe", "_lrap"]
    with open(filename, opType) as file:
        for i in range(len(dataSet)):
            file.write(dataSet[i])
            file.write("\n\t")
            for j in range(len(method)):
                file.write(method[j])
                file.write("\n\t\t")
                featureSelectFileName = result_path + str(bins) + "/" + dataSet[i] + "_" + method[j] + "_" + "Selected_feature"
                isFinishFeatureSelect = Path(featureSelectFileName).is_file()
                file.write("isFinishFeatureSelect:")
                file.write("\n\t\t\t")
                file.write(str(int(isFinishFeatureSelect)))
                file.write("\n\t\t")
                classifyLabelFileName = result_path + str(bins) + "/" + dataSet[i] + "_" + method[j] + "_" + "predict_"
                file.write("isFinishClassify:")
                file.write("\n\t\t\t")
                for k in range(threshold):
                    isFinishClassify = Path(classifyLabelFileName + str(k+1) + ".npz").is_file()
                    if not isFinishClassify:
                        break
                file.write(str(k + 1))
                file.write("\n\t\t")
                file.write("isOver:")
                is_over = True
                for m in metric:
                    if not Path(result_path + str(bins) + "/" + dataSet[i] + "_" + method[j] + "_Result" + m).is_file():
                        is_over = False
                        break
                file.write("\n\t\t\t")
                file.write(str(int(is_over)))
                file.write("\n\t")
            file.write("\n")


def reWriteLogArg(result_path, dataSet, feature_selection):
    filename = result_path + "log.txt"
    _reWriteLog(filename, "w", dataSet, feature_selection)


def _reWriteLog(filename, opType, dataSet, feature_selection):
    metric = ["_h", "_z", "_mi", "_ma", "_rank", "_co", "_jaccard_ma", "_jaccard_mi", "_subSetAccuracy", "_ap", "_mi_auc", "_oe", "_lrap"]
    with open(filename, opType) as file:
        for i in range(len(dataSet)):
            file.write(dataSet[i])
            file.write("\n\t")
            feature_selection_i = feature_selection[i]
            for j in range(len(feature_selection_i)):
                file.write(feature_selection_i[j]["method"])
                file.write("\n\t\t")
                isFinishFeatureSelect = feature_selection_i[j]["isFinishFeatureSelect"]
                file.write("isFinishFeatureSelect:")
                file.write("\n\t\t\t")
                file.write(str(int(isFinishFeatureSelect)))
                file.write("\n\t\t")
                file.write("isFinishClassify:")
                file.write("\n\t\t\t")
                isFinishClassify = feature_selection_i[j]["isFinishClassify"]
                file.write(str(isFinishClassify))
                file.write("\n\t\t")
                file.write("isOver:")
                file.write("\n\t\t\t")
                file.write(str(int(feature_selection_i[j]["isOver"])))
                file.write("\n\t")
            file.write("\n")


# 更新记录
def _updateLog(result_path, filename, opType, bins, dataSets, feature_select, dataSet_t, feature_selection_t, threshold):
    metric = ["_h", "_z", "_mi", "_ma", "_rank", "_co", "_jaccard_ma", "_jaccard_mi", "_subSetAccuracy", "_ap", "_mi_auc", "_oe", "_lrap"]
    for i in range(len(dataSet_t)):
        if dataSet_t[i] in dataSets:
            # 在在已经记录的log里面
            feature_selection_i = feature_select[dataSets.index(dataSet_t[i])]
        else:
            # 不在记录的log里面
            dataSets.append(dataSet_t[i])
            feature_selection_i = []
            feature_select.append(feature_selection_i)
        feature_selection_t_i = feature_selection_t[i]
        for j in range(len(feature_selection_t_i)):
            feature_selection_item = {}
            feature_selection_item.update(method=feature_selection_t_i[j])
            featureSelectFileName = result_path + str(bins) + "/" + dataSet_t[i] + "_" + feature_selection_t_i[
                j] + "_" + "Selected_feature"
            isFinishFeatureSelect = Path(featureSelectFileName).is_file()
            feature_selection_item.update(isFinishFeatureSelect=isFinishFeatureSelect)
            classifyLabelFileName = result_path + str(bins) + "/" + dataSet_t[i] + "_" + feature_selection_t_i[
                j] + "_" + "predict_"
            for k in range(threshold):
                isFinishClassify = Path(
                    classifyLabelFileName + str(k + 1) + ".npz").is_file()
                if not isFinishClassify:
                    break
            feature_selection_item.update(isFinishClassify=str(k + 1))
            is_over = True
            for m in metric:
                if not Path(result_path + str(bins) + "/" + dataSet_t[i] + "_" + feature_selection_t_i[
                j] + "_Result" + m).is_file():
                    is_over = False
                    break
            feature_selection_item.update(isOver=str(int(is_over)))
            feature_selection_i.append(feature_selection_item)
    _reWriteLog(filename, opType, dataSets, feature_select)


# 初始化log
def initlog(result_path, bins, dataSet, method, threshold):
    filename = result_path + str(bins) + "/log.txt"
    opType = "w"
    # 这两个列表保存了需要初始化记录的信息
    dataSet_t = dataSet.copy()
    method_list = []
    for i in range(len(dataSet)):
        method_list.append(method.copy())
    if Path(filename).is_file():
        # 解析文件
        dataSets, feature_select = fetchLog(filename)
        isOver = False
        for i in dataSets:
            # 这个数据集需要记录的方法
            index_Log = dataSets.index(i)
            if i in dataSet_t:
                index = dataSet_t.index(i)
                for j in feature_select[index_Log]:
                    if j["method"] in method_list[index]:
                        t = method_list[index]
                        t.remove(j["method"])
                # 所有的方法都记录完成
                if not method_list[index]:
                    dataSet_t.remove(i)
                    method_list.pop(index)
        if not dataSet_t:
            return
        _updateLog(result_path, filename, opType, bins, dataSets, feature_select, dataSet_t, method_list, threshold)
    else:
        _initlogFile(result_path, filename, opType, bins, dataSet, method, threshold)


# 得到状态表
def fetchLogArg(result_path, bins):
    filename = result_path + str(bins) + "/log.txt"
    return fetchLog(filename)


# 解析log文件
def fetchLog(filename):
    dataSets = []
    feature_selection = []
    with open(filename, "r") as file:
        dataSet = file.readline().replace("\n", "")
        while dataSet:
            dataSets.append(dataSet)
            if "\t" != file.read(1):
                raise Exception("格式错误")
            method = file.readline().replace("\n", "")
            feature_selection_i = []
            while method:
                feature_selection_item = {}
                feature_selection_item.update(method=method)
                if "\t\tisFinishFeatureSelect:\n" != file.readline():
                    raise Exception("格式错误")
                if "\t\t\t" != file.read(3):
                    raise Exception("格式错误")
                feature_selection_item.update(isFinishFeatureSelect=bool(int(file.readline().replace("\n", ""))))
                if "\t\tisFinishClassify:\n" != file.readline():
                    raise Exception("格式错误")
                if "\t\t\t" != file.read(3):
                    Exception("格式错误")
                feature_selection_item.update(isFinishClassify=int(file.readline().replace("\n", "")))
                if "\t\tisOver:\n" != file.readline():
                    raise Exception("格式错误")
                if "\t\t\t" != file.read(3):
                    Exception("格式错误")
                feature_selection_item.update(isOver=bool(int(file.readline().replace("\n", ""))))
                if "\t" != file.read(1):
                    raise Exception("格式错误")
                method = file.readline().replace("\n", "")
                feature_selection_i.append(feature_selection_item)
            feature_selection.append(feature_selection_i)
            dataSet = file.readline().replace("\n", "")
    return dataSets, feature_selection


def destroyLog(result_path, bins):
    filename = result_path + str(bins) + "/log.txt"
    os.remove(filename)
